package com.star.controller;

import com.star.controller.viewobject.CommentVO;
import com.star.controller.viewobject.CountcommentVO;
import com.star.error.BusinessException;
import com.star.error.EmBusinessError;
import com.star.response.CommonReturnType;
import com.star.service.CommentService;
import com.star.service.model.CommentModel;
import com.star.write.Writelog;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@Controller("comment")
@RequestMapping("/comment")
@CrossOrigin(allowCredentials = "true", allowedHeaders = "*")
public class CommentController extends BaseController {
    @Autowired
    private CommentService commentService;

    @RequestMapping(value = "/create", method = {RequestMethod.POST}, consumes = {CONTENT_TYPE_FORMED})
    @ResponseBody
    public CommonReturnType createComment(@RequestParam(name="commentContent") String commentContent,
                                          @RequestParam(name="commentDate") String commentDate,
                                          @RequestParam(name="userId") Integer userId,
                                          @RequestParam(name="articleId") Integer articleId) throws BusinessException {
        CommentModel commentModel = new CommentModel();
        commentModel.setCommentContent(commentContent);
        commentModel.setCommentDate(commentDate);
        commentModel.setUserId(userId);
        commentModel.setArticleId(articleId);

        commentModel = commentService.createComment(commentModel);

        CommentVO commentVO = convertFromModel(commentModel);
        Writelog writelog = new Writelog();
        writelog.saveAsFileWriter("create the comment");
        return CommonReturnType.create(commentVO);
    }

    @RequestMapping(value = "/delete", method = {RequestMethod.POST})
    @ResponseBody
    public String deleteComment(@RequestParam(name="commentId") Integer commentId){
        commentService.deleteComment(commentId);
        Writelog writelog = new Writelog();
        writelog.saveAsFileWriter("delete the comment");
        System.out.println("delete controller");
        return "success";
    }

    @RequestMapping(value = "/count", method = {RequestMethod.GET})
    @ResponseBody
    public CountcommentVO countComment(@RequestParam(name="articleId") Integer articleId){
        Writelog writelog = new Writelog();
        writelog.saveAsFileWriter("count the comment");
        CountcommentVO countcommentVO = new CountcommentVO();
        countcommentVO.setCountcomment(commentService.countComment(articleId));
        return countcommentVO;
    }

    @RequestMapping("/get")
    @ResponseBody
    public CommonReturnType getComment(@RequestParam(name="commentId") Integer commentId) throws BusinessException{
        CommentModel commentModel = commentService.getCommentById(commentId);
        if(commentModel == null){
            throw new BusinessException(EmBusinessError.COMMENT_NOT_EXIST);
        }
        CommentVO commentVO = convertFromModel(commentModel);
        Writelog writelog = new Writelog();
        writelog.saveAsFileWriter("get the comment");
        return CommonReturnType.create(commentVO);
    }

    @RequestMapping(value = "/listbyarticle", method = {RequestMethod.GET})
    @ResponseBody
    public CommonReturnType listCommentByArticle(@RequestParam(name="articleId",required = false) Integer articleId){
        List<CommentModel> commentByArticleModelList = commentService.listCommentByArticle(articleId);
        System.out.println(articleId);
        List<CommentVO> commentByArticleVOList = commentByArticleModelList.stream().map(commentByArticleModel -> {
            CommentVO commentByArticleVO = convertFromModel(commentByArticleModel);
            return commentByArticleVO;
        }).collect(Collectors.toList());
        Writelog writelog = new Writelog();
        writelog.saveAsFileWriter("list the comment by article");
        return CommonReturnType.create(commentByArticleVOList);
    }

    @RequestMapping(value = "/listbyuser", method = {RequestMethod.GET})
    @ResponseBody
    public CommonReturnType listCommentByUser(@RequestParam(name="userId") Integer userId){
        List<CommentModel> commentByUserModelList = commentService.listCommentByUser(userId);

        List<CommentVO> commentByUserVOList = commentByUserModelList.stream().map(commentByUserModel -> {
            CommentVO commentByUserVO = convertFromModel(commentByUserModel);
            return commentByUserVO;
        }).collect(Collectors.toList());
        Writelog writelog = new Writelog();
        writelog.saveAsFileWriter("list the comment by user");
        return CommonReturnType.create(commentByUserVOList);
    }

    private CommentVO convertFromModel(CommentModel commentModel){
        if(commentModel == null){
            return null;
        }

        CommentVO commentVO = new CommentVO();
        BeanUtils.copyProperties(commentModel, commentVO);

        return commentVO;
    }
}
