package com.star.service.impl;

import com.star.dao.ReportDOMapper;
import com.star.dataobject.ReportDO;
import com.star.error.BusinessException;
import com.star.service.ReportService;
import com.star.service.model.ReportModel;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class ReportServiceImpl implements ReportService {
    @Autowired
    private ReportDOMapper reportDOMapper;

    @Override
    public ReportModel getReportById(Integer reportId){
        ReportDO reportDO = reportDOMapper.selectByPrimaryKey(reportId);

        if(reportDO == null){
            return null;
        }

        ReportModel reportModel = convertFromDataObject(reportDO);

        return reportModel;
    }

    @Override
    @Transactional
    public ReportModel createReport(ReportModel reportModel) throws BusinessException {
        ReportDO reportDO = convertFromModel(reportModel);
        reportDOMapper.insertSelective(reportDO);

        reportModel.setReportId(reportDO.getReportId());

        return getReportById(reportModel.getReportId());
    }

    @Override
    public List<ReportModel> listReport() {
        List<ReportDO> reportDOList = reportDOMapper.listReport();

        List<ReportModel> reportModelList = reportDOList.stream().map(reportDO -> {
            ReportModel reportModel = convertFromDataObject(reportDO);
            return reportModel;
        }).collect(Collectors.toList());
        return reportModelList;
    }

    @Override
    public void deleteReport(Integer reportId){
        reportDOMapper.deleteByPrimaryKey(reportId);
    }

    private ReportDO convertFromModel(ReportModel reportModel){
        if(reportModel == null){
            return null;
        }

        ReportDO reportDO = new ReportDO();
        BeanUtils.copyProperties(reportModel, reportDO);

        return reportDO;
    }

    private ReportModel convertFromDataObject(ReportDO reportDO){
        if(reportDO == null){
            return null;
        }

        ReportModel reportModel = new ReportModel();
        BeanUtils.copyProperties(reportDO, reportModel);

        return reportModel;
    }
}
