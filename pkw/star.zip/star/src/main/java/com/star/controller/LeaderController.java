package com.star.controller;

import com.star.controller.viewobject.LeaderVO;
import com.star.error.BusinessException;
import com.star.error.EmBusinessError;
import com.star.response.CommonReturnType;
import com.star.service.LeaderService;
import com.star.service.model.LeaderModel;
import com.star.write.Writelog;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@Controller("leader")
@RequestMapping("/leader")
@CrossOrigin(allowCredentials = "true", allowedHeaders = "*")
public class LeaderController extends BaseController {
    @Autowired
    private LeaderService leaderService;

    @RequestMapping(value = "/create", method = {RequestMethod.POST}, consumes = {CONTENT_TYPE_FORMED})
    @ResponseBody
    public CommonReturnType createLeader(@RequestParam(name="leaderName") String leaderName,
                                          @RequestParam(name="leaderPost") String leaderPost,
                                          @RequestParam(name="leaderIntro") String leaderIntro) throws BusinessException {
        LeaderModel leaderModel = new LeaderModel();
        leaderModel.setLeaderName(leaderName);
        leaderModel.setLeaderPost(leaderPost);
        leaderModel.setLeaderIntro(leaderIntro);

        leaderModel = leaderService.createLeader(leaderModel);

        LeaderVO leaderVO = convertFromModel(leaderModel);
        Writelog writelog = new Writelog();
        writelog.saveAsFileWriter("create the leader");
        return CommonReturnType.create(leaderVO);
    }

    @RequestMapping(value = "/delete", method = {RequestMethod.POST})
    @ResponseBody
    public String deleteLeader(@RequestParam(name="leaderId") Integer leaderId){
        leaderService.deleteLeader(leaderId);
        Writelog writelog = new Writelog();
        writelog.saveAsFileWriter("delete the leader");
        System.out.println("delete controller");
        return "success";
    }

    @RequestMapping("/get")
    @ResponseBody
    public CommonReturnType getLeader(@RequestParam(name="leaderId") Integer leaderId) throws BusinessException{
        LeaderModel leaderModel = leaderService.getLeaderById(leaderId);
        if(leaderModel == null){
            throw new BusinessException(EmBusinessError.LEADER_NOT_EXIST);
        }
        LeaderVO leaderVO = convertFromModel(leaderModel);
        Writelog writelog = new Writelog();
        writelog.saveAsFileWriter("get the leader");
        return CommonReturnType.create(leaderVO);
    }

    @RequestMapping(value = "/list", method = {RequestMethod.GET})
    @ResponseBody
    public CommonReturnType listLeader(){
        List<LeaderModel> leaderModelList = leaderService.listLeader();

        List<LeaderVO> leaderVOList = leaderModelList.stream().map(leaderModel -> {
            LeaderVO leaderVO = convertFromModel(leaderModel);
            return leaderVO;
        }).collect(Collectors.toList());
        Writelog writelog = new Writelog();
        writelog.saveAsFileWriter("list the leader");
        return CommonReturnType.create(leaderVOList);
    }

    @RequestMapping(value = "/update", method = {RequestMethod.POST},consumes = {CONTENT_TYPE_FORMED})
    @ResponseBody
    public String updateLeader(@RequestParam(name="leaderName",required = false) String leaderName,
                               @RequestParam(name="leaderIntro",required = false) String leaderIntro,
                               @RequestParam(name="leaderPost",required = false) String leaderPost)
            throws BusinessException{
        leaderService.updateLeader(leaderName,leaderIntro,leaderPost);
        Writelog writelog = new Writelog();
        writelog.saveAsFileWriter("change the leader");
        return "success";
    }

    private LeaderVO convertFromModel(LeaderModel leaderModel){
        if(leaderModel == null){
            return null;
        }

        LeaderVO leaderVO = new LeaderVO();
        BeanUtils.copyProperties(leaderModel, leaderVO);

        return leaderVO;
    }
}
