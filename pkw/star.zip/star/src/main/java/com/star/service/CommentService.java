package com.star.service;

import com.star.error.BusinessException;
import com.star.service.model.ArticletagModel;
import com.star.service.model.CommentModel;

import java.util.List;

public interface CommentService {
    CommentModel getCommentById(Integer id);
    CommentModel createComment(CommentModel commentModel) throws BusinessException;
    List<CommentModel> listCommentByArticle(Integer articleId);
    List<CommentModel> listCommentByUser(Integer userId);
    void deleteComment(Integer id);
    int countComment(Integer articleId);
}
