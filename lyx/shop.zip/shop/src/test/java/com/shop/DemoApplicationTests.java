package com.shop;

import com.shop.model.Goods;
import com.shop.repository.GoodsRep;
import com.shop.service.GoodsService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;

@SpringBootTest
class DemoApplicationTests {
    @Autowired
    private GoodsService service;

    @Autowired
    private GoodsRep rep;

    @Test
    void contextLoads() {
        service.findGoodsById("1");
    }

}
