package com.shop.response;


public class Response {
    private String status;

    private Object data;

    public static Response create(Object result){

        return create(result, "success");
    }

    public static Response create(Object result, String status){

        Response type = new Response();
        type.setStatus(status);
        type.setData(result);

        return type;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Object getData() {
        return data;
    }

    public void setData(Object data) {
        this.data = data;
    }
}
