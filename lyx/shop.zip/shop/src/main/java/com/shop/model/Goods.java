package com.shop.model;

public class Goods {
    String name;

    String lib;

    String id;

    String region;

    String state;

    String description;

    String price;

    String actualPrice;

    String lib2;

    public Goods(String name, String lib, String region, String state, String description, String price, String actualPrice) {
        this.name = name;
        this.lib = name;
        this.region = region;
        this.state = state;
        this.description = description;
        this.price = price;
        this.actualPrice = actualPrice;
    }

    public Goods() {

    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getLib() {
        return lib;
    }

    public void setLib(String lib) {
        this.lib = lib;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getRegion() {
        return region;
    }

    public void setRegion(String region) {
        this.region = region;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getActualPrice() {
        return actualPrice;
    }

    public void setActualPrice(String actualPrice) {
        this.actualPrice = actualPrice;
    }

    public String getLib2() {
        return lib2;
    }

    public void setLib2(String lib2) {
        this.lib2 = lib2;
    }
}
