package com.shop.rowMapper;


import com.shop.model.Goods;
import com.shop.model.Order;
import org.springframework.jdbc.core.RowMapper;
import java.sql.ResultSet;
import java.sql.SQLException;


public class OrderRowMapper implements RowMapper<Order> {
    @Override
    public Order mapRow(ResultSet resultSet, int i) throws SQLException {
        Order order = new Order();
        order.setId(String.valueOf(resultSet.getInt("id")));
        order.setUserId(String.valueOf(resultSet.getInt("userid")));
        order.setGoodsId(String.valueOf(resultSet.getInt("goodsId")));
        order.setPrice(String.valueOf(resultSet.getInt("price")));
        order.setDate(resultSet.getString("date"));
        order.setActualPrice(String.valueOf(resultSet.getInt("actualPrice")));
        order.setTotalPrice(String.valueOf(resultSet.getInt("totalPrice")));
        order.setNum(String.valueOf(resultSet.getInt("num")));
        return order;
    }


}
