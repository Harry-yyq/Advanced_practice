package com.shop.repository;

import com.shop.model.Goods;
import com.shop.rowMapper.GoodsRowMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public class GoodsRep {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    public List<Goods> findAll() {
        return jdbcTemplate.query("SELECT * FROM shop.GOODS", new GoodsRowMapper());
    }

    public List<Goods> findByRegion(String region) {
        return jdbcTemplate.query("SELECT * FROM shop.GOODS WHERE REGION = " + region,
                new GoodsRowMapper());
    }

    public Goods findById(String id) {
        return jdbcTemplate.queryForObject("SELECT * FROM shop.GOODS WHERE ID = " + id,
                new GoodsRowMapper());
    }

    public int addFirstPicture(String name, String id) {
        return jdbcTemplate.update("UPDATE shop.GOODS SET LIB = " + name + " WHERE id = " + id);
    }

    public int addSecondPicture(String name, String id) {
        return jdbcTemplate.update("UPDATE shop.GOODS SET LIB2 = " + name + " WHERE id = " + id);
    }



    public int create(String name, String lib, String region,
                       String state, String description, String price, String actualPrice) {
        return jdbcTemplate.update("INSERT INTO shop.GOODS" +
                " (name, lib, region, state, price, description, actualPrice) " +  "VALUES" +
                " (" + "\'" + name + "\'" + ", " + "\'" + lib + "\'" + ", " + region + ", "+
                "\'" + state + "\'" + ", " + price + ", " + "\'" + description+ "\'" + ", " + actualPrice + ")");

    }

    public int delete(String id) {
        return jdbcTemplate.update("UPDATE shop.GOODS SET STATE = \"delete\" WHERE ID = " + id);
    }

    public int pass(String id) {
        return jdbcTemplate.update("UPDATE shop.GOODS SET STATE = \"show\" WHERE ID = " + id);
    }

    public int modifyGoods(String id, String name, String description, String actualPrice, String url) {
        Goods oldGoods = jdbcTemplate.queryForObject("SELECT * FROM shop.GOODS WHERE ID = " + id, new GoodsRowMapper());
        String oldUrl = oldGoods.getLib();
        String urlList[] = oldUrl.split("&");
        return jdbcTemplate.update("UPDATE shop.GOODS SET LIB = " + "\"" + url + "&" + urlList[1] + "\"" + "," +
                "name=" + "\"" + name + "\"" + "," + "description = " + "\"" + description + "\"" +
                "," + "actualPrice = " + actualPrice + " WHERE ID = " + id);
    }



}
