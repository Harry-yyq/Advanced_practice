package com.shop.service;

import com.shop.model.Goods;
import com.shop.repository.GoodsRep;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class GoodsService {
    @Autowired
    private GoodsRep goodsRep;

    public List<Goods> findAllSimply() {
        List<Goods> goods = goodsRep.findAll();
        return  goods;
    }

    public List<Goods> findGoodsByRegion(String region) {
        List<Goods> goods = goodsRep.findByRegion(region);
        return goods;
    }

    public Goods findGoodsById(String id) {
        Goods goods = goodsRep.findById(id);
        return goods;
    }

    public Goods createOneGoods(String name, String lib, String region,
                                String state, String description, String price, String actualPrice) {
        goodsRep.create(name, lib, region, state, description, price, actualPrice);
        return new Goods(name, lib, region, state, description, price, actualPrice);
    }

    public Goods deleteOneGoods(String id){
        goodsRep.delete(id);
        return new Goods();
    }

    public Goods passOneGoods(String id) {
        goodsRep.pass(id);
        return new Goods();
    }

    public Goods addFirstPicture(String name, String id) {
        goodsRep.addFirstPicture(name, id);
        return new Goods();
    }

    public Goods addSecondPicture(String name, String id) {
        goodsRep.addSecondPicture(name, id);
        return new Goods();
    }

    public Goods modifyGoods(String id, String name, String description, String actualPrice, String url) {
        goodsRep.modifyGoods(id, name, description, actualPrice, url);
        return new Goods();
    }
}
