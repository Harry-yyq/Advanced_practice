package com.shop.repository;

import com.shop.model.Goods;
import com.shop.model.Order;
import com.shop.rowMapper.GoodsRowMapper;
import com.shop.rowMapper.OrderRowMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class OrderRep {
    @Autowired
    private JdbcTemplate jdbcTemplate;

    public List<Order> findByUserId(String userId) {
        return jdbcTemplate.query("SELECT * FROM shop.ORDER WHERE USERID = " + userId,
                new OrderRowMapper());
    }

    public List<Order> findAll() {
        return jdbcTemplate.query("SELECT * FROM shop.ORDER", new OrderRowMapper());
    }

    public int create(String userId, String price, String goodsId,
                      String date, String actualPrice, String totalPrice, String num) {
        return jdbcTemplate.update("INSERT INTO shop.ORDER" +
                " (userId, price, goodsId, date, actualPrice, totalPrice, num) " +  "VALUES" +
                " (" + userId + ", " + price + ", " + goodsId + ", "+
                "\'" + date + "\'" + ", " + actualPrice + ", " + totalPrice + ", " + num + ")");

    }
}
