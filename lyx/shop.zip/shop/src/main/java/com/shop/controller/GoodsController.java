package com.shop.controller;


import com.mysql.cj.protocol.x.Notice;
import com.qcloud.cos.COSClient;
import com.qcloud.cos.ClientConfig;
import com.qcloud.cos.auth.BasicCOSCredentials;
import com.qcloud.cos.auth.COSCredentials;
import com.qcloud.cos.model.PutObjectRequest;
import com.qcloud.cos.region.Region;
import com.shop.model.Goods;
import com.shop.response.Response;
import com.shop.service.GoodsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;

import java.io.*;
import java.util.List;


@RestController
@RequestMapping("/shop/goods")
@CrossOrigin
public class GoodsController {

    @Autowired
    private GoodsService goodsService;

    @GetMapping("showAllGoods")
    public Response showAllGoods() {
        List<Goods> goodsList = goodsService.findAllSimply();
        for(int i = 0; i < goodsList.size(); i++) {
            String[] libs = goodsList.get(i).getLib().split("&");
            if(libs.length > 1) {
                goodsList.get(i).setLib2(libs[1]);
                goodsList.get(i).setLib(libs[0]);
            }
            else goodsList.get(i).setLib2("https://advance-1301930426.cos.ap-beijing.myqcloud.com/none/2018-07-05 (4).png");
        }
        if(goodsList.size() == 0) {
            return Response.create("none", "fail");
        }
        return Response.create(goodsList, "success");
    }

    @GetMapping("showRegionGoods")
    public Response showRegionGoods(@RequestParam(name="region")String region) {
        List<Goods> goodsList = goodsService.findGoodsByRegion(region);
        if(goodsList.size() == 0) {
            return Response.create("none", "fail");
        }
        return Response.create(goodsList, "success");
    }

    @GetMapping("getGoods")
    public Response getGoodsById(@RequestParam(name="id")String id) {
        Goods oneGoods = goodsService.findGoodsById(id);
        String[] libs = oneGoods.getLib().split("&");
        if(libs.length > 1) {
            oneGoods.setLib2(libs[1]);
            oneGoods.setLib(libs[0]);
        }
        else oneGoods.setLib2("https://advance-1301930426.cos.ap-beijing.myqcloud.com/none/2018-07-05 (4).png");
        return Response.create(oneGoods, "success");
    }

    @PostMapping("createGoods")
    public Response createGoods(@RequestParam(name="name") String name, @RequestParam(name="lib")
                               String lib, @RequestParam(name="region")String region,
                               @RequestParam(name="state")String state, @RequestParam(name="description")
                               String description, @RequestParam(name="price")String price,
                               @RequestParam(name="actualPrice")String actualPrice) {
        Goods oneGoods = goodsService.createOneGoods(name, lib, region, state,description, price, actualPrice);
        return Response.create(oneGoods, "success");
    }

    @PostMapping("deleteGoods")
    public Response deleteGoods(@RequestParam(name="id") String id) {
        Goods oneGoods = goodsService.deleteOneGoods(id);
        return Response.create(oneGoods, "success");
    }

    @PostMapping("passGoods")
    public Response passGoods(@RequestParam(name="id") String id) {
        Goods oneGoods = goodsService.passOneGoods(id);
        return Response.create(oneGoods,"success");
    }

    @PostMapping("addPicture")
    @ResponseBody
    public Response addPicture(@RequestParam(name="key")String key,
                             @RequestParam(name="file") MultipartFile file) {
        String name = "";
        if (!file.isEmpty()) {
            try {
                BufferedOutputStream out = new BufferedOutputStream(
                        new FileOutputStream(new File(file.getOriginalFilename())));
                name = file.getOriginalFilename();
                out.write(file.getBytes());
                out.flush();
                out.close();
            } catch (IOException e) {
                e.printStackTrace();
                return Response.create(e.getMessage(), "fail");
            }

            File localFile = new File(name);
            // 上传到桶里的文件名
            String cosKey = key + localFile.getName();
            System.out.println(cosKey);

            COSCredentials cred = new BasicCOSCredentials("AKIDNWUCcVOsgU2RZmbSt37vZxCAAuMhHiR0"
                    , "Ss2vWr2wZwHxNp1bvylIirwlnZ5KMios");
            ClientConfig clientConfig = new ClientConfig(new Region("ap-beijing"));
            COSClient cosClient = new COSClient(cred, clientConfig);

            PutObjectRequest putObjectRequest = new PutObjectRequest("advance-1301930426", cosKey, localFile);
            cosClient.putObject(putObjectRequest);
            cosClient.shutdown();

            return Response.create("https://advance-1301930426.cos.ap-beijing.myqcloud.com/" +
                    cosKey, "success");

        } else {
            return Response.create("none", "fail");
        }

    }

    @PostMapping("modifyGoods")
    @ResponseBody
    public Response mdyPicture(@RequestParam(name="id")String id,
                               @RequestParam(name="name")String name,
                               @RequestParam(name="description")String description,
                               @RequestParam(name="actualPrice")String actualPrice,
                               @RequestParam(name="url")String url) {
        Goods goods = goodsService.modifyGoods(id, name, description, actualPrice, url);
        return Response.create(goods, "success");

    }

}
