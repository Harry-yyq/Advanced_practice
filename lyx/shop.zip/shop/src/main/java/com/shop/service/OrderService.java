package com.shop.service;

import com.shop.model.Order;
import com.shop.repository.OrderRep;
import com.sun.org.apache.xpath.internal.operations.Or;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class OrderService {
    @Autowired
    private OrderRep orderRep;

    public List<Order> findOrderByUserId(String id) {
        List<Order> orders = orderRep.findByUserId(id);
        return orders;
    }

    public List<Order> findAll() {
        List<Order> orders = orderRep.findAll();
        return orders;
    }

    public Order createOneOrder(String userId, String price, String goodsId,
                                String date, String actualPrice, String totalPrice, String num) {
        orderRep.create(userId, price, goodsId, date, actualPrice, totalPrice, num);
        return new Order(userId, price, goodsId, date, actualPrice, totalPrice, num);
    }
}
