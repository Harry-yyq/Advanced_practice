package com.shop.model;

public class Order {
    String id;

    String userId;

    String goodsId;

    String price;

    String date;

    String actualPrice;

    String totalPrice;

    String num;

    String lib1;

    String lib2;

    public Order(String userId, String goodsId, String price, String date,
                 String actualPrice, String totalPrice, String num) {
        this.userId = userId;
        this.goodsId = goodsId;
        this.price = price;
        this.date = date;
        this.actualPrice = actualPrice;
        this.totalPrice = totalPrice;
        this.num = num;
    }

    public Order() {

    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getGoodsId() {
        return goodsId;
    }

    public void setGoodsId(String goodsId) {
        this.goodsId = goodsId;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getActualPrice() {
        return actualPrice;
    }

    public void setActualPrice(String actualPrice) {
        this.actualPrice = actualPrice;
    }

    public String getNum() {
        return num;
    }

    public void setNum(String num) {
        this.num = num;
    }

    public String getTotalPrice() {
        return totalPrice;
    }

    public void setTotalPrice(String totalPrice) {
        this.totalPrice = totalPrice;
    }

    public String getLib1() {
        return lib1;
    }

    public void setLib1(String lib1) {
        this.lib1 = lib1;
    }

    public String getLib2() {
        return lib2;
    }

    public void setLib2(String lib2) {
        this.lib2 = lib2;
    }
}
