package com.shop.rowMapper;


import com.shop.model.Goods;
import org.springframework.jdbc.core.RowMapper;
import java.sql.ResultSet;
import java.sql.SQLException;


public class GoodsRowMapper implements RowMapper<Goods> {
    @Override
    public Goods mapRow(ResultSet resultSet, int i) throws SQLException {
        Goods goods = new Goods();
        goods.setId(String.valueOf(resultSet.getInt("id")));
        goods.setName(resultSet.getString("name"));
        goods.setLib(resultSet.getString("lib"));
        goods.setRegion(String.valueOf(resultSet.getInt("region")));
        goods.setState(resultSet.getString("state"));
        goods.setDescription(resultSet.getString("description"));
        goods.setPrice(resultSet.getString("price"));
        goods.setActualPrice(String.valueOf(resultSet.getInt("actualPrice")));
        return goods;
    }


}
