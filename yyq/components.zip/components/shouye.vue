<template>
  <div>
    <div class="OldShouye-Body-Sign">
      <el-carousel style="height: 600px;">
        <el-carousel-item style="height: 600px;" v-for="(item,index) in items" :key="index">
          <img :src="item.idView" class="el-image" style="width: 100%;height: 600px;" />
        </el-carousel-item>
      </el-carousel>
    </div>
    <div class="OldShouye-Body-Introduce">
      <!-- 广告语 -->
      <div style="width: 500px;height: 100px;display: flex;flex-direction: column;">
        <div style="width: 100%;height: 40px;display: flex;justify-content: center;font-size: 30px;color: #0099e5;">{{Feature[0]}}</div>
        <div style="width: 100%;height: 20px;display: flex;justify-content: center;font-size: 15px;color: #707070;margin-top: 20px; ">{{Feature[1]}}</div>
      </div>
    </div>
    <!-- 平台总体介绍 -->
    <div style="width: 100%;display: flex;justify-content: center;margin-top: 20px;">
      <div style="width: 1000px;height: 300px;display: flex;flex-direction: row;justify-content: space-around;">
        <div class="OldShouye-Introduce-Allimg" @click="HealthRecordLink">
          <div class="OldShouye-Introduce-img">
            <img :src="SkipDetails[0].src" class="OldShouye-Introduce-img" />
          </div>
          <div class="OldShouye-Introduce-word">
            <div class="OldShouye-Introduce-Bigword">{{SkipDetails[0].name}}</div>
            <div class="OldShouye-Introduce-Smallword">{{SkipDetails[0].introduce}}</div>
          </div>
        </div>
        <div class="OldShouye-Introduce-Allimg" @click="FamilyDoctorLink">
          <div class="OldShouye-Introduce-img">
            <img :src="SkipDetails[1].src" class="OldShouye-Introduce-img" />
          </div>
          <div class="OldShouye-Introduce-word">
            <div class="OldShouye-Introduce-Bigword">{{SkipDetails[1].name}}</div>
            <div class="OldShouye-Introduce-Smallword">{{SkipDetails[1].introduce}}</div>
          </div>
        </div>
        <div class="OldShouye-Introduce-Allimg" @click="ConsultationLink">
          <div class="OldShouye-Introduce-img">
            <img :src="SkipDetails[2].src" class="OldShouye-Introduce-img" />
          </div>
          <div class="OldShouye-Introduce-word">
            <div class="OldShouye-Introduce-Bigword">{{SkipDetails[2].name}}</div>
            <div class="OldShouye-Introduce-Smallword">{{SkipDetails[2].introduce}}</div>
          </div>
        </div>
      </div>
    </div>

    <div class="OldShouye-Body-Doctor">
      <div class="OldShouye-Body-Doctor-Background">
        <img src="../assets/shouye/yinhe1.jpg" style="width: 100%;height: 1000px;" />
      </div>
      <!-- 医生介绍 -->
      <div style="width: 100%;height: 100px;display: flex;justify-content: center;">
        <div style="width: 500px;height: 100px;display: flex;flex-direction: column;">
          <div style="width: 100%;height: 40px;display: flex;justify-content: center;font-size: 30px;color: #0099e5;">{{DoctorFeature[0]}}</div>
          <div style="width: 100%;height: 20px;display: flex;justify-content: center;font-size: 15px;color: #707070;margin-top: 20px; ">{{DoctorFeature[1]}}</div>
        </div>
      </div>

      <div style="width: 100%;display: flex;justify-content: center;margin-top: 20px;">
        <div style="width: 1000px;height: 300px;display: flex;flex-direction: row;justify-content: space-around;">
          <div class="OldShouye-Body-Doctor-All">
            <div class="OldShouye-Body-Doctor-Img">
              <img :src="goodsSrc[0].lib" class="OldShouye-Body-Doctor-Img" />
            </div>
            <div class="OldShouye-Body-Doctor-BigWord">{{goodsSrc[0].name}}</div>
            <div class="OldShouye-Body-Doctor-SmallWord1">{{goodsSrc[0].description}}</div>
            <div class="OldShouye-Body-Doctor-SmallWord1">{{goodsSrc[0].price}}</div>
            <div class="OldShouye-Body-Doctor-SmallWord2">{{goodsSrc[0].state}}</div>
          </div>
          <div class="OldShouye-Body-Doctor-All">
            <div class="OldShouye-Body-Doctor-Img">
              <img :src="goodsSrc[1].lib" class="OldShouye-Body-Doctor-Img" />
            </div>
            <div class="OldShouye-Body-Doctor-BigWord">{{goodsSrc[1].name}}</div>
            <div class="OldShouye-Body-Doctor-SmallWord1">{{goodsSrc[1].description}}</div>
            <div class="OldShouye-Body-Doctor-SmallWord1">{{goodsSrc[1].price}}</div>
            <div class="OldShouye-Body-Doctor-SmallWord2">{{goodsSrc[1].state}}</div>
          </div>
          <div class="OldShouye-Body-Doctor-All">
            <div class="OldShouye-Body-Doctor-Img">
              <img :src="goodsSrc[2].lib" class="OldShouye-Body-Doctor-Img" />
            </div>
            <div class="OldShouye-Body-Doctor-BigWord">{{goodsSrc[2].name}}</div>
            <div class="OldShouye-Body-Doctor-SmallWord1">{{goodsSrc[2].description}}</div>
            <div class="OldShouye-Body-Doctor-SmallWord1">{{goodsSrc[2].price}}</div>
            <div class="OldShouye-Body-Doctor-SmallWord2">{{goodsSrc[2].state}}</div>
          </div>
          <div class="OldShouye-Body-Doctor-All">
            <div class="OldShouye-Body-Doctor-Img">
              <img :src="goodsSrc[3].lib" class="OldShouye-Body-Doctor-Img" />
            </div>
            <div class="OldShouye-Body-Doctor-BigWord">{{goodsSrc[3].name}}</div>
            <div class="OldShouye-Body-Doctor-SmallWord1">{{goodsSrc[3].description}}</div>
            <div class="OldShouye-Body-Doctor-SmallWord1">{{goodsSrc[3].price}}</div>
            <div class="OldShouye-Body-Doctor-SmallWord2">{{goodsSrc[3].state}}</div>
          </div>

        </div>
      </div>
    </div>
  </div>


  </div>

  </div>
</template>

<script>
import axios from 'axios';
import Qs from 'qs'
export default {
  data() {
    return {
      //介绍数组
      count:[],
      DoctorFeature:[
        '旅行介绍',
        '浏览于星系之间，徜徉于未来之中'
      ],
      items: [{
        id: 0,
        idView: require('../assets/shouye/yinhe1.jpg')
      },
        {
          id: 1,
          idView: require("../assets/shouye/yinhe2.jpg")
        },
        {
          id: 0,
          idView: require('../assets/shouye/yinhe3.jpg')
        },
        {
          id: 0,
          idView: require('../assets/shouye/yinhe4.jpg')
        },
        {
          id: 1,
          idView: require("../assets/shouye/yinhe5.jpg")
        },
        {
          id: 0,
          idView: require('../assets/shouye/yinhe6.jpg')
        },
      ],
      //存放广告语
      Feature: [
        '平台特色',
        '在这里，你将望眼于宇宙；在这里，你可以实现你的太空梦！'
      ],
      //存放四个跳转介绍栏的内容
      SkipDetails: [{
        src: require('../assets/shouye/lvxing.jpg'),
        name: '太空旅行',
        introduce: '宇宙地图，特色旅行，总有你喜欢的'
      },
        {
          src: require('../assets/shouye/shequ.jpg'),
          name: '太空社区',
          introduce: '帖子，评论去寻找真实的太空'
        },
        {
          src: require('../assets/shouye/gongsi.jpg'),
          name: '关于我们',
          introduce: '点进来了解一下挖掘机太空公司叭'
        },
      ],
      goodsSrc:[],


    }
  },
  mounted() {
    this.creat();
  },

  methods: { //跳转页面

    creat() {
      console.log("获取商品数据");
      axios.get('http://192.168.43.175:8080/shop/goods/showAllGoods').then(response => {
        if (response.data.status == 'success') {
          this.goodsSrc = response.data.data;
          //console.log(this.NewSrc);
          console.log(response.data.data)
        } else {
          console.error("获取机器列表失败")
        }
      })
    },

    HealthRecordLink() {
      this.$router.push({
        path: '/shangcheng'
      })
    },
    FamilyDoctorLink() {
      this.$router.push({
        path: '/FamilyDoctor'
      })
    },
    ConsultationLink() {
      this.$router.push({
        path: '/company'
      })
    },
    PersonalLink() {
      this.$router.push({
        path: '/company'
      })
    }

  }
}
</script>

<style scoped>
.OldShouye-Body-Sign {
  margin-top: 0px;
  height: 600px;
  width: 100%;
}

.OldShouye-Body-Introduce {
  width: 100%;
  height: 80px;
  margin-top: 30px;
  display: flex;
  justify-content: center;
}

.OldShouye-Introduce-Allimg {
  width: 160px;
  height: 300px;
  display: flex;
  flex-direction: column;
  transition: 0.2s;
}

.OldShouye-Introduce-Allimg:hover {
  transform: scale(1.1, 1.1);
}

.OldShouye-Introduce-img {
  width: 100%;
  height: 200px;
}

.OldShouye-Introduce-word {
  width: 100%;
  height: 100px;
  display: flex;
  flex-direction: column;
  justify-content: space-around;
  background-color: #0099e5;
}

.OldShouye-Introduce-Bigword {
  width: 100%;
  height: 30px;
  display: flex;
  justify-content: center;
  font-size: 23px;
  background-color: transparent;
  color: white;
}

.OldShouye-Introduce-Smallword {
  width: 100%;
  height: 30px;
  display: flex;
  justify-content: center;
  font-size: 8px;
  background-color: transparent;
  color: white;
}

.OldShouye-Body-Doctor {
  width: 100%;
  height: 1000px;
  margin-top: 40px;
  display: flex;
  flex-direction: column;
}

.OldShouye-Body-Doctor-Background {
  height: 100%;
  width: 100%;
  z-index: -1;
  position: absolute;
  opacity: 0.3;
  filter: "alpha(opacity=50)";
  -ms-filter: "alpha(opacity=80)";
  /* 旧版IE */
}

.OldShouye-Body-Doctor-All {
  width: 200px;
  height: 300px;
  display: flex;
  flex-direction: column;
  border: 1px solid #555555;
  border-radius: 3px;
}

.OldShouye-Body-Doctor-Img {
  width: 100%;
  height: 180px;
}

.OldShouye-Body-Doctor-BigWord {
  height: 40px;
  font-size: 23px;
  color: #000000;
  margin-top: 3px;
}

.OldShouye-Body-Doctor-SmallWord1 {
  height: 20px;
  font-size: 15px;
  margin-top: 3px;
  color: #555555;
}

.OldShouye-Body-Doctor-SmallWord2 {
  height: 20px;
  font-size: 6px;
  margin-top: 3px;
  color: #555555;
}

.OldShouye-Body-Hospital-All {
  height: 400px;
  width: 300px;
  display: flex;
  flex-direction: column;
  justify-content: space-around;
}

.OldShouye-Body-Hospital-Img {
  height: 250px;
  width: 100%;
}

.OldShouye-Body-Hospital-Word1 {
  height: 50px;
  width: 100%;
  font-size: 25px;
  color: #0099e5;
}

.OldShouye-Body-Hospital-Word2 {
  height: 30px;
  width: 100%;
  font-size: 15px;
  color: #ff0000;
}

.OldShouye-Body-Hospital-Word3 {
  height: 30px;
  width: 100%;
  font-size: 15px;
  color: #555555;
}
</style>
