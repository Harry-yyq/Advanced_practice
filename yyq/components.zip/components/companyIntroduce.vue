<template>
  <div>
    <div v-for="(item,index) in introduction" >
      <div style="font-size: 25px;color: #000000;">
        {{introduction[index].companyIntro}}
      </div>
    </div>
  </div>

</template>

<script>
import axios from 'axios';
import Qs from 'qs';
export default {
  data() {
    return {
      SrcCount: '1',
      PresidentImg: require('../assets/company/3.jpg'),
      PresidentName: '马辰',
      CEOImg: require('../assets/company/2.jpg'),
      CEOName: '姚毅强',
      CFOImg: require('../assets/company/1.jpg'),
      CFOName: '姚毅强',
      CTOImg: require('../assets/company/2.jpg'),
      CTOName: '姚毅强',
      tableData:[],
      introduction:[]

    };
  },
  mounted() {
    this.creat();
  },

  methods: {

    //请求公告数据
    creat: function() {
      console.log("kaishila");
      axios.get('http://192.168.43.120:8080/company/list').then(response => {
        if (response.data.status == 'success') {
          this.introduction = response.data.data;
          //this.$data.introduction = this.tableData
          console.log(this.tableData);
          console.log("获取机器列表成功")
        } else {
          console.error("获取机器列表失败")
        }
      })

    },

  }

}
</script>

<style>
</style>
