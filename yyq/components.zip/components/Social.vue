
<template>
<div class="page">
  {{this.tagValue}}
    <div class= "wrapper">
        <!-- 页面正文 -->
        <div class="main_content">
            <!-- 标题栏 -->
            <div class="main_header">
                <!-- 标题栏各项 -->
                <div class="header-inner">
                 <!-- 搜索栏 -->
                    <div class="head_search">
                        <div class="head_search_cont">
                          <el-input v-model="searchvalue" type="text" placeholder=" 查找"  onblur=" "></el-input>
                        </div>
                    </div>
                    <div class="head_user">
                        <el-row v-model="tagValue">
                          <el-select  placeholder="请选择" v-model="tagValue">
                            <el-option  v-for="item in tagList" :key="item.tagId" :label="item.tagName" :value="item.tagId">
                            </el-option>
                          </el-select>
                        </el-row>
                    </div>
                </div>
            </div>

            <div class="post-newer" @click="create">
              <div class ="post-newer-holder" v-if="!createVisible">
                说点什么吧
              </div>
              <div class="post_new" v-if="createVisible">
                <div class="post-new-media">
                    <div class="post-new-media-user">
                        <img src="../assets/images/avatars/avatar-2.jpg" alt="">
                    </div>
                    <div class="post-new-media-input">
                        <el-input  type="textarea" v-model="exampleArticle.articleTitle" placeholder="请输入内容" clearable ></el-input>
                    </div>
                </div>
                <el-divider class="eldivider"> </el-divider>
                <div class="post-new-type">
                    <a>
                        <img src="../assets/images/icons/photo.png" alt="">
                        <el-upload class="upload-demo"  multiple :before-upload="beforeUpload" :http-request="request" list-type="picture">
                            <el-button size="mini"  type="primary"> 照片</el-button>
                        </el-upload>
                    </a>
                  <div class ="post_new_pub"> <el-button @click="createArticle"  type="success" icon="el-icon-check" round>发布</el-button></div>
                  </div>
                </div>
            </div>
            <div class="post-list" v-for= "v in articlelist" :key="v.articleId">
              <div class="post">
                <el-container class="post-heading" height="20px">
                  <el-aside  height="40px" width="auto">
                    <img :src="getUserAva(v.userId)"  alt="">
                  </el-aside>
                  <el-container height="40px">
                    <el-header height= "24px">{{v.userId}}</el-header>
                    <el-footer height="16px">
                        <span>{{v.articleDate}} </span>
                    </el-footer>
                  </el-container>
                  <el-container  class="delete-icon"  v-if="mageflag">
                    <i class="el-icon-delete" @click="dialogVisible = true"></i>
                    <el-dialog  title="提示" :visible.sync="dialogVisible"  width="30%"  :before-close="handleClose">
                      <span>确定要删除吗?</span>
                      <span slot="footer" class="dialog-footer">
                        <el-button @click="dialogVisible = false">取 消</el-button>
                        <el-button type="primary" @click="deleteArticle(v.articleId)">确 定</el-button>
                      </span>
                    </el-dialog>
                  </el-container>
                </el-container>
                <el-divider class= "eldivider"> </el-divider>
                <el-container class="post-description">
                  <el-main >
                    <div class ="fullsizeimg" >{{v.articleTitle}}</div>
                    <div >
                      <img class="post-img" :src="v.articleContent" alt="">
                    </div>
                  </el-main>
                  <el-footer  class="post-d-footer" height="32px">
                      <el-button :type="LikeType" icon ="el-icon-star-on" size="mini" @click="changeLike(v.articleId,v.userId)" circle></el-button>
                      <el-button type="primary" icon ="el-icon-chat-dot-square" size="mini"  @click="changeComFlag" circle></el-button>
                  </el-footer>
                  <el-divider class="eldivider"> </el-divider>
                </el-container>
                  <div class="post-state" v-for="com in exampleComment[v.userId]" :key="com.commentId" >
                      {{com.userId}} :{{com.commentContent}}
                  </div>
                <div class="post-state" v-if="createCommentFlag" >
                  <el-input class="comment-input" v-if="createCommentFlag" type="textarea" :rows="1" placeholder="请输入内容" v-model="comContent"> </el-input>
                  <el-button type ="primary" class="comment-button" @click="createComment(v.articleId)">提交</el-button>
                </div>
                </div>


            </div>
        </div>
    </div>
</div>
</template>


<!--                    <el-button  @click="createArticle"></el-button>-->
<!--                    <el-button  @click="deleteArticle"> 删除</el-button>-->
<!--                    <el-button  @click="listbyuserArticle"> 查找</el-button>-->
<!--                    <el-button  @click="createComment">添加评论</el-button>-->
<!--                    <el-button  @click="listComment">加载评论</el-button>-->
<!--                    <el-button  @click="countComment">计数评论</el-button>-->
<!--                    <el-button  @click="deleteComment">删除评论</el-button>-->
<!--                    <el-button  @click="createTag">创建标签</el-button>-->
<!--                    <el-button  @click="listTag">列出标签</el-button>-->
<!--                    <el-button  @click="deleteTag">删除标签</el-button>-->
<!--                    <el-button  @click="getTag">查找标签</el-button>-->
<!--                    <el-button  @click="createArticleLike">点赞</el-button>-->
<!--                    <el-button  @click="countArticleLike">点赞数</el-button>-->
<!--                    <el-button  @click="deleteArticleLike">取消点赞</el-button>-->
<!--                    <el-button  @click="createArticleTag"> 给文章加标签 </el-button>-->
<!--                    <el-button  @click="articleListByTagId">根据标签筛选文章</el-button>-->
<!--                    <el-button  @click="deleteArticleTag">删除文章的标签</el-button>-->

<script>
import axios from 'axios'
import Qs from 'qs'

export default {

  name: 'Social',
  data () {
    return {
      id: '',
      perFlag: 0,
      createVisible: false,
      friendVisible: false,
      dialogVisible: false,
      tagList: [
        {tagId: 1, tagName:'red'},
        {tagId: 2, tagName:'blue'},
        {tagId: 3, tagName:'sad'}
      ],
      dataObj: new FormData(),
      arcCreate:{
      },
      headerobj: {
        Authorization: "Bearer " + window.sessionStorage.getItem("token"),
        "Content-Type": "multipart/form-data"
      },
      uploadurl:'https://advance-1301930426.cos.ap-beijing.myqcloud.com/another/',
      imgdata:{
        key: "4.jpg",
      },

      searchvalue: '',
      newinput: '',
      tagValue:'',
      comContent:'',
      fileList: [],
      friendlist: [{id: 123456, name: 'pkw'}, {id: 1234567, name: 'mc'}, {id: 1234,name: 'yyq'}, {id: 12345678,name: 'lyx' }],
      articlelist: [
        {
          articleId: '1',
          articleTitle: 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim laoreet dolore magna aliquam erat volutpat',
          articleContent: "https://advance-1301930426.cos.ap-beijing.myqcloud.com/post/1.jpg",
          articleDate: '11.6',
          userId: 1
        },
        {
          articleId: '2',
          articleTitle: 'sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim laoreet dolore magna aliquam erat volutpat',
          articleContent: 'https://advance-1301930426.cos.ap-beijing.myqcloud.com/post/2.jpg',
          articleDate: '11.5',
          userId: 2}
        // }, {
        //   articleId: '13',
        //   articleTitle: 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim laoreet dolore magna aliquam erat volutpat',
        //   articleContent: ['../assets/images/post/img-3.jpg'],
        //   articleDate: '11.5',
        //   userId: 1234567
        // }
      ],
      articleLieList: [
        {
          articleLikeId: 7777777,
          articleId: 111111,
          likeNum: 15
        },
        {
          articleLikeId: 7777778,
          articleId: 111112,
          likeNum: 15
        }
      ],
      likeflag: false,
      mageflag:false,
      createCommentFlag:false,
      commentList: {},
      likeNum: 15,
      LikeType: "info",
      info: '',
      exampleArticle:{
        articleTitle:"",
        //https://advance-1301930426.cos.ap-beijing.myqcloud.com/post/avatar-4.jpg
        articleContent: "",
        articleDate: "2020-11-20",
        userId: "111"
      },

      exampleComment:[{
        commentContent:"this is 1st user's 1st comment",
        commentDate: "2020-01-01",
        userId: "1",
        articleId: "1",
      },{
        commentContent:"this is 1st user's 1st comment",
        commentDate: "2020-01-01",
        userId: "2",
        articleId: "1",
      }],
      exampleArticleTag:{
        articleId: "2",
        articleTitle: "this is article tag",
        articleContent:"this is articletag's content",
        commentContent:"this is 1st user's 1st comment",
        articleDate: "2020-01-03",
        tagId:1,
        tagName:"red",
        userId: "1",
      },
      exampleTag:{
        tagName:"happy"
      },
    }
  },

  methods: {
    async request(file) {
      console.log(file.file);
      axios({
        headers: {
          'Content-Type': 'application/form-data'
        },
        method: 'post',
        url: 'http://192.168.43.175:8080/shop/goods/addPicture',
        data:
          this.dataObj
      }).then(response => (this.exampleArticle.articleContent = response.data.data)
      )
        .catch(function (error) { // 请求失败处理
        console.log(error)
        })
    },

    getUserAva: function (userId){
      return require("../assets/images/avatars/avatar-"+userId+".jpg");
    },

    getDate: function (){
      var newDate = new Date();
      return (newDate.getMonth()+1)+"-"+newDate.getDate()+"-"+newDate.getHours()+"-"+newDate.getMinutes();
    },
    beforeUpload: function (file){
        console.log("post/test/"+file.name)
        this.dataObj.append("key","article/"+file.name);
        this.dataObj.append("file", file);
        console.log(this.dataObj)
      },

    create: function(){
        this.createVisible =true;
      },
    selected: function (userId){
      console.log(userId);
      this.newinput = this.newinput +userId;
      },
    // uploadimg: function (e){
      //   let self = this
      //   let file = e.target.files[0]
      //   /* eslint-disable no-undef */
      //   let param = new FormData()  // 创建form对象
      //   param.append('file', file)  // 通过append向form对象添加数据
      //   param.append('chunk', '0') // 添加form表单中其他数据
      //   console.log(param.get('file')) // FormData私有类对象，访问不到，可以通过get判断值是否传进去
      //   axios({
      //     headers: {
      //       'Content-Type': 'application/x-www-form-urlencoded'
      //     },
      //     method: 'post',
      //     url: 'https://advance-1301930426.cos.ap-beijing.myqcloud.com/another',
      //     data: {
      //       key: "article/post.jpg",
      //       file: param
      //     }
      //
      //   })
      //     .then(response => (this.info = response.data
      //       ,console.log("this is deleteArticle In ",response.data))
      //     ).catch(function (error) { // 请求失败处理
      //     console.log(error)
      //   })
      // },
    listbyuserArticle:function (){
        axios({
          headers: {
            'Content-Type': 'application/x-www-form-urlencoded'
          },
          method: 'get',
          url: 'http://192.168.43.120:8080/article/listbyuser',
          params:{
            userId: 111
          }
        })
          .then(response => (this.info = response.data
            ,console.log("this is listbyuserArticle ",response.data))
          ).catch(function (error) { // 请求失败处理
          console.log(error)
        })
      },
    //创建评论
    createComment:function(aID){
      this.exampleComment.commentContent = this.comContent;
      this.exampleComment.articleId = aID;
      this.exampleComment.userId =this.id;
      console.log("this is create Comment",this.exampleComment)
        axios({
          headers: {
            'Content-Type': 'application/x-www-form-urlencoded'
          },
          method: 'post',
          url: 'http://192.168.43.120:8080/comment/create',
          data: Qs.stringify(
            this.exampleComment
          )
        })
          .then(response => (this.info = response.data
            ,console.log("this is crateComment In ",response.data))
          ).catch(function (error) { // 请求失败处理
          console.log(error)
        })
      },
    //计数评论
    countComment:function (){
      console.log("this is count Comment")
      axios({
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded'
        },
        method: 'get',
        url: 'http://192.168.43.120:8080/comment/count',
        params: {
          articleId:1
        }
      })
        .then(response => (this.info = response.data
          ,console.log("this is count Comment",response.data))
        ).catch(function (error) { // 请求失败处理
        console.log(error)
      })
    },
    //删除评论
    deleteComment:function (){
      console.log("this is delete Comment",this.exampleComment)
      axios({
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded'
        },
        method: 'post',
        url: 'http://192.168.43.120:8080/comment/delete',
        data: Qs.stringify({
          commentId: 3}
        )
      })
        .then(response => (this.info = response.data
          ,console.log("this is deleteComment  ",response.data))
        ).catch(function (error) { // 请求失败处理
        console.log(error)
      })
    },
    //展示评论
    listComment: function (){
        axios({
          headers: {
            'Content-Type': 'application/x-www-form-urlencoded'
          },
          method: 'get',
          url: 'http://192.168.43.120:8080/comment/listbyarticle',
          params: {
            articleId:1
            }
        })
          .then(response => (this.commentList = response.data
            ,console.log("this is listComment ",response.data))
          ).catch(function (error) { // 请求失败处理
          console.log(error)
        })
      },

    //创建标签
    createTag:function(){
      console.log("this is create Tag",this.exampleTag)
      axios({
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded'
        },
        method: 'post',
        url: 'http://192.168.43.120:8080/tag/create',
        data: Qs.stringify(
          this.exampleTag
        )
      })
        .then(response => (this.info = response.data
          ,console.log("this is create Tag In ",response.data))
        ).catch(function (error) { // 请求失败处理
        console.log(error)
      })
     },
    //列出标签
    listTag: function (){
      axios({
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded'
        },
        method: 'get',
        url: 'http://192.168.43.120:8080/tag/list',
      })
        .then(response => (this.info = response.data
          ,console.log("this is listTag ",response.data))
        ).catch(function (error) { // 请求失败处理
        console.log(error)
      })
    },
    //删除评论
    deleteTag:function (){
      console.log("this is delete Tag",this.exampleComment)
      axios({
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded'
        },
        method: 'post',
        url: 'http://192.168.43.120:8080/tag/delete',
        data: Qs.stringify({
          tagId:2}
        )
      })
        .then(response => (this.info = response.data
          ,console.log("this is delete Tag  ",response.data))
        ).catch(function (error) { // 请求失败处理
        console.log(error)
      })
    },
    //列出标签
    getTag: function (){
      axios({
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded'
        },
        method: 'get',
        url: 'http://192.168.43.120:8080/tag/get',
        params:{
          tagId:1
        }
      })
        .then(response => (this.info = response.data
          ,console.log("this is get Tag ",response.data))
        ).catch(function (error) { // 请求失败处理
        console.log(error)
      })
    },

    changeLike:function (aID, uId){
      if( this.likeflag == false ){
        this.createArticleLike(aID,uId)
        this.LikeType = 'primary';
        this.likeflag = true;
      }
      else{
        this.deleteArticleLike(aID,uId)
        this.LikeType = 'info';
        this.likeflag= false;
      }
    },

    //点赞
    createArticleLike:function(aID, uId){
      console.log("this is create ArticleLike")
      axios({
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded'
        },
        method: 'post',
        url: 'http://192.168.43.120:8080/articlelike/create',
        data: Qs.stringify(
          {
            articleId:aID,
            userId:uId
          }
        )
      })
        .then(response => (this.info = response.data
          ,console.log("this is crate Arcticlelike ",response.data))
        ).catch(function (error) { // 请求失败处理
        console.log(error)
      })
    },


    //点赞数
    countArticleLike:function(){
      console.log("this is count ArticleLike")
      axios({
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded'
        },
        method: 'get',
        url: 'http://192.168.43.120:8080/articlelike/count',
        params: {
            articleId:1
          }
      })
        .then(response => (this.info = response.data
          ,console.log("this is countArticleLike ",response.data))
        ).catch(function (error) { // 请求失败处理
        console.log(error)
      })
    },
    //取消点赞
    deleteArticleLike: function (){
      console.log("this is delete ArticleLike")
      axios({
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded'
        },
        method: 'post',
        url: 'http://192.168.43.120:8080/articlelike/delete',
        data: Qs.stringify(
          {
            articleId:1,
            userId:2
          }
        )
      })
        .then(response => (this.info = response.data
          ,console.log("this is delete ArticleLike ",response.data))
        ).catch(function (error) { // 请求失败处理
        console.log(error)
      })
    },
    //创建文章的标签
    createArticleTag:function (){
      console.log("this is create ArticleTag")
      axios({
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded'
        },
        method: 'post',
        url: 'http://192.168.43.120:8080/articletag/create',
        data: Qs.stringify(
          this.exampleArticleTag
        )
      })
        .then(response => (this.info = response.data
          ,console.log("this is crate ArticleLTag ",response.data))
        ).catch(function (error) { // 请求失败处理
        console.log(error)
      })
    },
    //根据标签筛选文章
    articleListByTagId:function (tId){
      if(tId!=null){
        console.log("this is articleListByTagId")
        axios({
          headers: {
            'Content-Type': 'application/x-www-form-urlencoded'
          },
          method: 'get',
          url: 'http://192.168.43.120:8080/articletag/listbytag',
          params: {
            tagId:tId
          }
        })
          .then(response => (this.info = response.data
            ,console.log("this is articleListByTagId ",response.data))
          ).catch(function (error) { // 请求失败处理
          console.log(error)
        })
      }
    },
    //删除文章的标签
    deleteArticleTag:function (){
      console.log("this is deleteArticleTag")
      axios({
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded'
        },
        method: 'post',
        url: 'http://192.168.43.120:8080/articletag/delete',
        data: {
          tagId:1,
          articleId:2,
        }
      })
        .then(response => (this.info = response.data
          ,console.log("this isdeleteArticleTag ",response.data))
        ).catch(function (error) { // 请求失败处理
        console.log(error)
      })
    },
    selectUser: function (){
      axios({
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded'
        },
        method: 'get',
        url: 'http://192.168.43.120:8080/user/list',
      })
        .then(response => (this.friendlist = response.data.data
          ,console.log("this is selectUser ",response.data.data))
        ).catch(function (error) { // 请求失败处理
        console.log(error)
      })
      this.friendVisible = true;
    },

    //创建帖子
    createArticle:function (){
      console.log("this s create Article",this.createVisible)
      axios({
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded'
        },
        method: 'post',
        url: 'http://192.168.43.120:8080/article/create',
        data: Qs.stringify(this.exampleArticle)
      })
        .then(response => (this.info = response.data
          ,console.log("this is deleteArticle In ",response.data))
        ).catch(function (error) { // 请求失败处理
        console.log(error)
      })
      this.createVisible = false;
      this.exampleArticle.articleDate = this.getDate();
    },
    //删除帖子
    deleteArticle: function (aId){
      // axios({
      //   headers: {
      //     'Content-Type': 'application/x-www-form-urlencoded'
      //   },
      //   method: 'post',
      //   url: 'http://192.168.43.120:8080/article/delete',
      //   data: Qs.stringify({
      //     articleId:aId }
      //   )
      // })
      //   .then(response => (this.fileList = response.data
      //     ,console.log("this is deleteArticle In ",response.data))
      //   ).catch(function (error) { // 请求失败处理
      //   console.log(error)
      // })
      this.dialogVisible = false;
    },
    //发布文章
    arcPub: function (){
      axios({
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded'
        },
        method: 'post',
        url: 'http://192.168.43.120:8080/article/create',
        data: Qs.stringify({
            articleTitle:2,
            articleContent: 2
        }
        )
      })
        .then(response => (this.fileList = response.data
          ,console.log("this is deleteArticle In ",response.data))
        ).catch(function (error) { // 请求失败处理
        console.log(error)
      })

      console.log("hshsh")
    },
    getImage: function (value) {
      return console.log(value)
    },
    handleRemove: function (file, fileList) {
      console.log(file, fileList)
    },
    handlePreview: function (file) {
      console.log(file)
    },
    handleExceed: function (files, fileList) {
      this.$message.warning(`当前限制选择 9 个文件，本次选择了 ${files.length} 个文件，共选择了 ${files.length + fileList.length} 个文件`)
    },
    beforeRemove: function (file, fileList) {
      return this.$confirm(`确定移除 ${file.name}?`)
    },
    handleClose(done) {
      this.$confirm('确认关闭？')
        .then(_ => {
          done();
        })
        .catch(_ => {});
    },
    changeComFlag: function (){
      this.createCommentFlag= !this.createCommentFlag;
    }
  },
  mounted () {
    console.log("this id console log this.info");
    axios
      .get('http://192.168.43.120:8080/article/list', {})
      .then(response => (this.articlelist = response.data.data)
      )
      .catch(function (error) { // 请求失败处理
        console.log(error)
      })
    this.id = sessionStorage.getItem("userId")
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
@import url("//unpkg.com/element-ui@2.14.1/lib/theme-chalk/index.css");

.page{
    margin-top:10px;
    display: inline-block;
    padding: 1.25rem 2rem;
    background: #2d4385;
    width: 50%;
    position: center;
    border-radius: 1%;
    margin-left:  20%;
}

.wrapper{
    background-color:#ffffff;
    position: center;
}


.main_content{
  position: relative;
  z-index: 5;
  display: block;
  margin-left: 30px;
  margin-right: 30px;
  overflow: visible;
  border-radius: 30px;
  min-height: 100vh;
  background-color: #ffffff;
  padding: 0 5px 2.5rem;
  align-items: center;
  justify-items: center;
}

/*标题栏*/
.main_header {
  z-index: 100;
  position: relative;
  display: flex;
  border-bottom: 1px solid #dee7ef;
}

.header-inner {
  margin: auto;
  width: 100%;
  display: flex;
  flex-direction: row;
  align-items: center;
  height: 70px;
}
/*搜索栏*/
.head_search {
  display:flex ;
  flex-grow: 7;
  position: relative;
  border-radius: 6px;
  z-index: 10001;
}
/* .head-form{
    width:100%
} */
/**搜索内容*/
.head_search_cont{
  position: relative;
  border-radius: 6px;
  z-index: 10001;
  width: 100%;
}

.head_search_cont input {
  text-align: center;
  height: 40px;
  color: #393939;
  outline: 0;
  background: #eaf0f5;
  border: 1px solid transparent;
  border-radius: 6px;
  width: 100%;
  font-size: 15px;
}

.head_user {
  margin-left: auto;
  display: flex;
  flex-grow: 2;
  align-items: center;
  justify-content: center;
}

.item {
  margin-top: 0px;
  margin-right: 30px;
}

.opts_icon_message {
  margin-right: 40px;
  padding: 5px 9px;
  border-radius: 100px;
  /* background-color: #f1f3f4; */
}

.opts_icon_message img {
  width: 26px;
  height: 26px;
}

.opts_icon_noti {
  font-size: 19px;
  padding: 5px 9px;
  border-radius: 100px;
  /* background-color: #f1f3f4; */
}

.opts_icon_noti img {
  width: 26px;
  height: 26px;
}
/*发布动态*/

.post-newer{
    border:1px solid #d2d2d2;
    border-radius: 6px;
    padding: 15px;
    margin-top: 15px;
}
post-newer-holder{
  text-align: center;
  font-family: 楷体;
}
.post_new{
  justify-content: center;
  justify-items: center;
}
.post-new {
  margin-bottom: 20px;
  background-color: #fff;
  border-radius: 3px;
  box-shadow: 0px 1px 9px -2px #d2d2d2;
  border-radius: 6px;
  padding: 16px;
  padding-bottom: 10px;
}
.post_new_pub{
  justify-content: center;
}
.post_new_pub el-button{
  justify-content: center;
  padding-left: 40%;
}
.post-new-media {
  display: flex;
  margin: 25px;
}

.post-new-media-user {
  width: auto;
  margin-right: 15px;
  margin-right: 15px;

}

.post-new-media-user img {
  width: 40px;
  height: 40px;
  border-radius: 50%;
}

.post-new-media-input {
  flex: 1;
  min-width: 1px;
}

.post-new-media-input .uk-input {
  border-radius: 50px;
  border-color: #f1f3f4;
  background-color: #f1f3f4;
  font-size: 17px;
}

.post-new-hr {
  margin: 8px 0;
}

.el-divider{
     margin: 8px 0;
     background: 0 0;
     border-top: 1px solid #e8eaec;
}

.post-new-type{
    display: flex;
    align-items: center;
}

.post-new-type a {
  flex: auto;
  min-width: 1px;
  display: flex;
  align-items: center;
  padding: 5px 10px;
  border-radius: 5px;
  justify-content: center;
}

.post-new-type a:hover {
  background-color: #f1f3f4
}

.post-new-type a img {
  width: 23px;
  margin: 7px;
}

.post-new-media-input .uk-input {
  border-radius: 50px;
  border-color: #f1f3f4;
  background-color: #f1f3f4;
  font-size: 17px;
}

.post-list{
  margin-top: 20px;
}
.post {
  margin-bottom: 20px;
  background-color: #fff;
  border-radius: 3px;
  box-shadow: 0px 1px 9px -2px #d2d2d2;
  border-radius: 6px;
  padding-bottom: 10px;
}

.post .post-heading {
  padding: 20px 15px;
  display: flex;
  padding-bottom: 0;
  position: relative;
}

.post-heading .post-avature {
  width: auto
}

.post-heading .post-avature img {
  width: 40px;
  height: 40px;
  border-radius: 100%;
}

.post-heading .post-title {
  margin-left: 15px;
  flex: 1;
  min-width: 1px;
}

.post-heading .post-title h4 {
  font-size: 16px;
  margin-bottom: -1px;
}

.post-heading .post-title p {
  font-size: 13px;
  margin-bottom: 0;
  font-weight: 600;
  color: #7d7d7d;
}

.post-heading .post-title p i {
  margin-left: 8px
}

.post-heading .post-btn-action {
  right: 0;
  top: 0;
  width: auto;
  height: 25px;
}

.post-heading .post-btn-action span.icon-more {
  width: 29px;
  height: 3px;
  position: relative;
  border-radius: 100%;
}

.post-heading .post-btn-action span.icon-more::before {
  font-family: "unicons";
  font-size: 22px;
  content: '\e99e';
  line-height: 30px;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -80%);
  position: absolute;
}

.post .el-container {
  padding: 5px;
}
.post .el-container .el-aside {
  margin-left: 15px;
  justify-content: center;

}
.post .el-container .el-aside img{
  padding-top: 10px;
  width: 40px;
  height: 40px;
  border-radius: 100%;
}

.post .el-container .el-container{
  text-align: left;
  padding-right:4px;
}

.post .el-container .el-container .el-header{
  line-height:1;
  font-size: 20px;
}

.post .el-container .el-container .el-footer{
  margin-top: 2px;
}

.post-description{
  margin: 5px;
  display: block;
}

.post-description .el-main{
  margin: 0px;
  padding: 0px;
}

.post-description .fullsizeimage {
  max-height: 400px;
  margin-left: -15px;
  width: calc(100% + 10px);
  overflow: hidden;
  margin-bottom: 5px;
  margin-top: -10px;
  justify-content: left;
}
.post-d-footer{
  margin-top: 20px;
  display: inline-flex;
  margin-left: 70%;
  justify-items: right;
  width: 100%;
}
.post-description .el-footer{
  margin: 10px 10px 10px;
  padding-left: 80%;
}
.post-description .el-footer .el-button{
  margin-top: 4px;

}

.fullsizeimage img{
  max-height: none;
  border: 0;
  padding: 0;
  border-radius: 0;
  border: solid #464141;
}
.post .post-state {
  width: 100%;
  margin-left: 6%;
  margin-top: 10px;
  margin-bottom: 10px;
  height:30px;
  text-align: left;
  display: flex;
}
.post-img{
  margin-top: 10px;
  width: 90%;
  padding-left: 5%;
  padding-right: 2%;
  border-radius: 6%;
}
.delete-icon{
  justify-items: center;
  justify-content: center;
  margin-top: 2%;
}
.fullsizeimg{
  margin-left: 6%;
  margin-right: 6%;
  margin-top: 5px;
  font-family: "Microsoft YaHei";
}
.grid-content {
  border-radius: 4px;
  min-height: 36px;
}
.el-row {
  margin-bottom: 20px;
}
.el-col {
  border-radius: 4px;
}
.comment-input{
  width: 70%;
  margin-right: 4%;
}
.comment-button{
  width:10%

}

</style>
