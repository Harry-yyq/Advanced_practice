<template>
	<div>
		<div style="width: 100%;height:7vh;">
			<el-divider content-position="left">
				<div style="font-size: 30px;color: #000000;">我的病人</div>
			</el-divider>
		</div>
		<!-- 查询栏 -->
		<div style="width: 100%;margin-left: 0px; height: 10vh;">
			<el-form :inline="true" :model="formData" class="demo-form-inline">
				<el-form-item label="姓名">
					<el-input v-model="formData.name" placeholder="老人姓名"></el-input>
				</el-form-item>
				<el-form-item label="关键字">
					<el-select v-model="formData.keyword" placeholder="关键字">
						<el-option label="区域一" value="shanghai"></el-option>
						<el-option label="区域二" value="beijing"></el-option>
					</el-select>
				</el-form-item>
				<el-form-item label="时间">
					<el-col :span="11">
						<el-date-picker type="date" placeholder="开始日期" v-model="formData.date1" style="width: 100%;"></el-date-picker>
					</el-col>
					<el-col class="line" :span="2">---</el-col>
					<el-col :span="11">
						<el-date-picker type="date" placeholder="结束日期" v-model="formData.date2" style="width: 100%;"></el-date-picker>
					</el-col>
				</el-form-item>
				<el-button @click="onSubmit" style="margin-left: 60px;">查询</el-button>
			</el-form>
		</div>

		<!--  -->
		<div style="width: 100%;">
			<el-table :data="tableData" style="width: 100%;" height="80vh">
				<el-table-column fixed prop="name" label="姓名" width="120">
				</el-table-column>
				<el-table-column prop="id" label="ID" width="100">
				</el-table-column>
				<el-table-column prop="community" label="社区" width="200">
				</el-table-column>
				<el-table-column prop="age" label="年龄" width="100">
				</el-table-column>
				<el-table-column prop="describe" label="病情描述" width="400">
				</el-table-column>
				<el-table-column  label="备注" width="400">
					<input v-model="remark" />
				</el-table-column>
				<el-table-column fixed="right" label="操作" width="100">
					<template slot-scope="scope">
						<el-button @click="chatClickBtn(scope.row)" type="text" size="medium">开启聊天</el-button>
					</template>
				</el-table-column>
				<el-table-column fixed="right" label="操作" width="100">
					<template slot-scope="scope">
						<el-button @click="applyClickBtn(scope.row)" type="text" size="medium">申请会诊</el-button>
					</template>
				</el-table-column>
			</el-table>
		</div>


	</div>
</template>

<script>
	export default {
		data() {
			return {
				formData: {
					name: '',
					keyword: '',
					data1: '',
					data2: '',
				},
				tableData: [{
						id: '5697111',
						name: '张三',
						community: '八里台广场社区',
						age: '69',
						describe: '胃部突然疼痛，平常不能正常吃饭胃部突然疼痛，平常不能正常吃饭胃部突然疼痛，平常不能正常吃饭胃部突然疼痛，平常不能正常吃饭',
						remark: '胃部不适，检查胃部，结果未下来',
					},
					{
						id: '5697111',
						name: '张三',
						community: '八里台广场社区',
						age: '69',
						describe: '胃部突然疼痛，平常不能正常吃饭',
						remark: '胃部不适，检查胃部，结果未下来',
					},
					{
						id: '5697111',
						name: '张三',
						community: '八里台广场社区',
						age: '69',
						describe: '胃部突然疼痛，平常不能正常吃饭',
						remark: '胃部不适，检查胃部，结果未下来',
					},
					{
						id: '5697111',
						name: '张三',
						community: '八里台广场社区',
						age: '69',
						describe: '胃部突然疼痛，平常不能正常吃饭',
						remark: '胃部不适，检查胃部，结果未下来',
					},
				]
			}
		},
		methods: {
			onSubmit() {
				console.log('submit!' + this.$data.formData.name);
			},
			applyClickBtn(row){
				console.log(row.remark)
				//this.$router.push({name: "doctorApply", params: {id:row.id , name:row.name,age:row.age,describe:row.describe}})
				
			},
			chatClickBtn(row){
				console.log(row.id)
				//this.$router.push("/doctorChat")
			},
			
		}
	}
</script>

<style>
</style>
