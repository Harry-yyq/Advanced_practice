<template>
  <div>
    <div class="Body-map">
      <backimg src="../assets/yinhe1.jpg" />
      <div class="All-map-picture">
        <div class="polygon-6-1" @click="LX1Btn">
          <img src="../assets/1.png" class="polygon-image" />
        </div>
        <div class="polygon-6-2"  @click="LX2Btn">
          <img src="../assets/2.png" class="polygon-image" />
        </div>
        <div class="polygon-6-3"  @click="LX3Btn">
          <img src="../assets/3.png" class="polygon-image" />
        </div>
        <div class="polygon-6-4"  @click="LX4Btn">
          <img src="../assets/4.png" class="polygon-image" />
        </div>
        <div class="polygon-6-5"  @click="LX5Btn">
          <img src="../assets/5.png" class="polygon-image" />
        </div>
        <div class="polygon-6-6"  @click="LX6Btn">
          <img src="../assets/6.png" class="polygon-image" />
        </div>
        <div class="polygon-6-7"  @click="LX7Btn">
          <img src="../assets/7.png" class="polygon-image" />
        </div>
        <div class="polygon-6-8"  @click="LX8Btn">
          <img src="../assets/8.png" class="polygon-image" />
        </div>
      </div>

    </div>

    <!-- 商城订单界面 -->
    <div style="height: 1000px; margin-top: 20px; width: 100%;display: flex;flex-direction: row;justify-content: center;">
      <div style="height: 500px; width: 1200px;display: flex;flex-direction: column;">
        <!-- 图片加介绍 -->
        <div style="display: flex;flex-direction: row;">
          <div style="width: 400px;height: 400px;display: flex;flex-direction: column;">
            <div><img :src="imgSrc" style="width: 400px;height: 300px;" /></div>
            <div style="margin-left: 120px;display: flex;flex-direction: row;margin-top: 10px;">
              <div style="width: 70px;height: 70px;margin-right: 20px;" @click="imgSrc1Btn">
                <img :src="imgSrc1" style="width: 70px;height: 70px;margin-right: 20px;" />
              </div>
              <div style="width: 70px;height: 70px;margin-right: 20px;" @click="imgSrc2Btn">
                <img :src="imgSrc2" style="width: 70px;height: 70px;margin-right: 20px;" />
              </div>
            </div>
          </div>

          <!-- 文字内容 -->
          <div style="width: 750px;height: 500px;background-color: #f2f3f2;margin-left: 20px;display: flex;flex-direction: column;">
            <div style="display: flex;flex-direction: row; margin-top: 10px;margin-left: 10px;">
              <div style="display: flex;flex-direction: column;justify-content: center; background-color: #ff4e4e; border: 0px;border-radius: 20%; color: #FFFFFF;width: 65px;">限时折扣</div>
              <div style="margin-left: 20px;font-size: 22px;">{{productionName}}</div>
            </div>

            <div style="height: 200px; margin-left: 2%;font-size: 20px;width: 98%;margin-top: 20px;">{{productionIntro}}</div>

            <el-divider></el-divider>

            <!-- 价格区域 -->
            <div style="display: flex;flex-direction: row;">
              <div style="font-size: 18px;margin-left: 10px;margin-top: 4px;">原价：</div>
              <div style="margin-top: 4px;font-size: 18px;text-decoration: line-through;margin-left: 10px;">{{productionPrice1}}</div>
              <div style="font-size: 24px;color:#ff4e4e ;margin-left: 0.9375rem;margin-top: 0rem;">{{productionPrice2}}</div>


            </div>

            <div style="margin-top:10px;display: flex;flex-direction: row;color: #000000;">
              <el-form ref="form" :model="form" label-width="80px">
                <el-form-item label="订单数量:">
                  <el-input-number style="margin-left: 1.25rem;" @change="handleChange" v-model="form.num" :min="0" :max="10"
                                   label="数量"></el-input-number>
                </el-form-item>
              </el-form>
              <el-form ref="form" :model="form">
                <el-form-item label="出发日期:" label-width="200px">
                  <el-col :span="16">
                    <el-form-item prop="date1">
                      <el-date-picker type="date" placeholder="选择" v-model="form.data" style="width: 100%;"></el-date-picker>
                    </el-form-item>
                  </el-col>
                </el-form-item>
              </el-form>
            </div>

            <div style="margin-top: 20px;display: flex;flex-direction: row;">
              <div style="width: 300px; font-size: 24px;color: #000000;margin-left: 300px;">总价：{{allPrice}}</div>
              <div style="margin-left: 30px;">
                <el-button @click="centerDialogVisible = true">提交订单</el-button>
                <el-dialog  title="提示" :visible.sync="centerDialogVisible" width="30%" center>
                  <span>确认提交吗</span>
                  <span slot="footer" class="dialog-footer">
                    <el-button @click="centerDialogVisible = false">取 消</el-button>
<!--                    centerDialogVisible = false-->
                    <el-button type="primary" @click="submitGoodBtn ">确定</el-button>
                  </span>
                </el-dialog>
              </div>
            </div>



          </div>

        </div>

      </div>
    </div>


  </div>



</template>

<script>
import axios from 'axios';
import Qs from 'qs'
export default {
  data() {
    return {
      goodsSrc:[],
      countGood:'',
      centerDialogVisible:false,
      imgSrc: require("../assets/shouye/gongsi.jpg"),
      imgSrc1: require("../assets/shouye/gongsi.jpg"),
      imgSrc2: require("../assets/shouye/lvxing.jpg"),
      productionId: '', //旅行id
      productionPrice1: 50000, //旅行价格
      productionPrice2: 45000, //旅行价格
      productionName: '去火星(可与家人一起享受外太空之旅)', //旅行剩余题目
      productionIntro: '非常非常号啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊非常非常号啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊非常非常号啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊非常非常号啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊', //旅行介绍
      productionNum: '32', //旅行剩余人数
      allPrice: 0,
      form: {//订单表单内容
        num: 0,
        insurance: '',
        data: ''

      },


    }
  },
  mounted() {
    this.creat();
  },
  methods: {
    //提交订单
    submitGoodBtn(){
      console.log("提交订单"+this.$data.form.data)
      let data = {
        userId:sessionStorage.getItem("userId"),
        price:this.$data.goodsSrc[this.$data.countGood].price,
        goodsId:this.goodsSrc[this.$data.countGood].id,
        date:this.$data.form.data,
        actualPrice:this.goodsSrc[this.$data.countGood].actualPrice,
        totalPrice:this.$data.allPrice,
        num:this.$data.form.num,
      }
      console.log(data)
      console.log("提交订单")
      axios({
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded'
        },
        method: 'post',
        url: 'http://192.168.43.175:8080/shop/order/createOrder',
        data: Qs.stringify(data)
      }).then(res => {
        console.log('res=>', res);
      })
    },
    //
    creat: function() {
      console.log("获取商品数据");
      axios.get('http://192.168.43.175:8080/shop/goods/showAllGoods').then(response => {
        if (response.data.status == 'success') {
          this.goodsSrc = response.data.data;
          //console.log(this.NewSrc);
          console.log(response.data.data)
        } else {
          console.error("获取机器列表失败")
        }
      })

    },

    handleChange() {
      this.$data.allPrice = this.$data.productionPrice2 * this.$data.form.num;
    },
    imgSrc1Btn() {
      this.$data.imgSrc = this.$data.imgSrc1;
    },
    imgSrc2Btn() {
      this.$data.imgSrc = this.$data.imgSrc2;
    },
    //从地图上选择相应的地方旅行
    LX1Btn(){//点击第一个地方
      //this.$data.imgSrc = this.$data.goodsSrc[0].lib;
      this.$data.imgSrc = this.$data.goodsSrc[0].lib;
      this.$data.imgSrc1 = this.$data.goodsSrc[0].lib;
      this.$data.imgSrc2 = this.$data.goodsSrc[0].lib2;
      this.$data.productionName = this.$data.goodsSrc[0].name;
      this.$data.productionPrice1 = this.$data.goodsSrc[0].price;
      this.$data.productionPrice2 = this.$data.goodsSrc[0].actualPrice;
      this.$data.productionIntro = this.$data.goodsSrc[0].description;
      this.countGood = 0

    },
    LX2Btn(){
      //localStorage.setItem("lastname", "Smith");这个是往缓存里面存东西
      // 检索
      //this.$data.imgSrc = this.$data.goodsSrc[0].lib;
      this.$data.imgSrc = this.$data.goodsSrc[1].lib;
      this.$data.imgSrc1 = this.$data.goodsSrc[1].lib;
      this.$data.imgSrc2 = this.$data.goodsSrc[1].lib2;
      this.$data.productionName = this.$data.goodsSrc[1].name;
      this.$data.productionPrice1 = this.$data.goodsSrc[1].price;
      this.$data.productionPrice2 = this.$data.goodsSrc[1].actualPrice;
      this.$data.productionIntro = this.$data.goodsSrc[1].description;
      this.countGood = 1
    },
    LX3Btn(){
      //this.$data.imgSrc = this.$data.goodsSrc[0].lib;
      this.$data.imgSrc = this.$data.goodsSrc[2].lib;
      this.$data.imgSrc1 = this.$data.goodsSrc[2].lib;
      this.$data.imgSrc2 = this.$data.goodsSrc[2].lib2;
      this.$data.productionName = this.$data.goodsSrc[2].name;
      this.$data.productionPrice1 = this.$data.goodsSrc[2].price;
      this.$data.productionPrice2 = this.$data.goodsSrc[2].actualPrice;
      this.$data.productionIntro = this.$data.goodsSrc[2].description;
      this.countGood = 2
    },
    LX4Btn(){
      //this.$data.imgSrc = this.$data.goodsSrc[0].lib;
      this.$data.imgSrc = this.$data.goodsSrc[3].lib;
      this.$data.imgSrc1 = this.$data.goodsSrc[3].lib;
      this.$data.imgSrc2 = this.$data.goodsSrc[3].lib2;
      this.$data.productionName = this.$data.goodsSrc[3].name;
      this.$data.productionPrice1 = this.$data.goodsSrc[3].price;
      this.$data.productionPrice2 = this.$data.goodsSrc[3].actualPrice;
      this.$data.productionIntro = this.$data.goodsSrc[3].description;
      this.countGood = 3
    },
    LX5Btn(){
      //this.$data.imgSrc = this.$data.goodsSrc[0].lib;
      this.$data.imgSrc = this.$data.goodsSrc[4].lib;
      this.$data.imgSrc1 = this.$data.goodsSrc[4].lib;
      this.$data.imgSrc2 = this.$data.goodsSrc[4].lib2;
      this.$data.productionName = this.$data.goodsSrc[4].name;
      this.$data.productionPrice1 = this.$data.goodsSrc[4].price;
      this.$data.productionPrice2 = this.$data.goodsSrc[4].actualPrice;
      this.$data.productionIntro = this.$data.goodsSrc[4].description;
      this.countGood = 4
    },
    LX6Btn(){
      //this.$data.imgSrc = this.$data.goodsSrc[0].lib;
      this.$data.imgSrc = this.$data.goodsSrc[5].lib;
      this.$data.imgSrc1 = this.$data.goodsSrc[5].lib;
      this.$data.imgSrc2 = this.$data.goodsSrc[5].lib2;
      this.$data.productionName = this.$data.goodsSrc[5].name;
      this.$data.productionPrice1 = this.$data.goodsSrc[5].price;
      this.$data.productionPrice2 = this.$data.goodsSrc[5].actualPrice;
      this.$data.productionIntro = this.$data.goodsSrc[5].description;
      this.countGood = 5
    },
    LX7Btn(){
      //this.$data.imgSrc = this.$data.goodsSrc[0].lib;
      this.$data.imgSrc = this.$data.goodsSrc[6].lib;
      this.$data.imgSrc1 = this.$data.goodsSrc[6].lib;
      this.$data.imgSrc2 = this.$data.goodsSrc[6].lib2;
      this.$data.productionName = this.$data.goodsSrc[6].name;
      this.$data.productionPrice1 = this.$data.goodsSrc[6].price;
      this.$data.productionPrice2 = this.$data.goodsSrc[6].actualPrice;
      this.$data.productionIntro = this.$data.goodsSrc[6].description;
      this.countGood = 6
    },
    LX8Btn(){
      //this.$data.imgSrc = this.$data.goodsSrc[0].lib;
      this.$data.imgSrc = this.$data.goodsSrc[7].lib;
      this.$data.imgSrc1 = this.$data.goodsSrc[7].lib;
      this.$data.imgSrc2 = this.$data.goodsSrc[7].lib2;
      this.$data.productionName = this.$data.goodsSrc[7].name;
      this.$data.productionPrice1 = this.$data.goodsSrc[7].price;
      this.$data.productionPrice2 = this.$data.goodsSrc[7].actualPrice;
      this.$data.productionIntro = this.$data.goodsSrc[7].description;
      this.countGood = 7
    },

  }
}
</script>

<style>
.Body-map {
  width: 100%;
  height: 550px;
  /* background-color: #020642; */
  display: flex;
  justify-content: center;
}

.All-map-picture {
  margin-top: 10px;
  width: 800px;
  z-index: 2;
}

.polygon-image {
  width: 200px;
  height: 200px;

}

.polygon-6-1 {
  position: absolute;
  -webkit-clip-path: polygon(25% 0, 75% 0, 100% 50%, 75% 100%, 25% 100%, 0 50%);
  clip-path: polygon(25% 0, 75% 0, 100% 50%, 75% 100%, 25% 100%, 0 50%);
  width: 200px;
  height: 200px;
  overflow: hidden;
  transition: 0.2s;
  z-index: 2;
}

.polygon-6-1:hover {
  /* border: 2px solid blue; */
  transform: scale(1.1, 1.1);
  z-index: 2;
}

.polygon-6-2 {
  position: absolute;
  -webkit-clip-path: polygon(25% 0, 75% 0, 100% 50%, 75% 100%, 25% 100%, 0 50%);
  clip-path: polygon(25% 0, 75% 0, 100% 50%, 75% 100%, 25% 100%, 0 50%);
  width: 200px;
  height: 200px;
  overflow: hidden;
  margin-left: 300px;
  transition: 0.2s;
}

.polygon-6-2:hover {
  /* border: 2px solid blue; */
  transform: scale(1.1, 1.1);
  z-index: 2;
}

.polygon-6-3 {
  position: absolute;
  -webkit-clip-path: polygon(25% 0, 75% 0, 100% 50%, 75% 100%, 25% 100%, 0 50%);
  clip-path: polygon(25% 0, 75% 0, 100% 50%, 75% 100%, 25% 100%, 0 50%);
  width: 200px;
  height: 200px;
  overflow: hidden;
  margin-left: 600px;
  transition: 0.2s;
}

.polygon-6-3:hover {
  /* border: 2px solid blue; */
  transform: scale(1.1, 1.1);
  z-index: 2;
}

.polygon-6-4 {
  position: absolute;
  -webkit-clip-path: polygon(25% 0, 75% 0, 100% 50%, 75% 100%, 25% 100%, 0 50%);
  clip-path: polygon(25% 0, 75% 0, 100% 50%, 75% 100%, 25% 100%, 0 50%);
  width: 200px;
  height: 200px;
  overflow: hidden;
  margin-top: 100px;
  margin-left: 150px;
  transition: 0.2s;
}

.polygon-6-4:hover {
  /* border: 2px solid blue; */
  transform: scale(1.1, 1.1);
  z-index: 2;
}

.polygon-6-5 {
  position: absolute;
  -webkit-clip-path: polygon(25% 0, 75% 0, 100% 50%, 75% 100%, 25% 100%, 0 50%);
  clip-path: polygon(25% 0, 75% 0, 100% 50%, 75% 100%, 25% 100%, 0 50%);
  width: 200px;
  height: 200px;
  overflow: hidden;
  margin-top: 100px;
  margin-left: 450px;
  transition: 0.2s;
}

.polygon-6-5:hover {
  /* border: 2px solid blue; */
  transform: scale(1.1, 1.1);
  z-index: 2;
}

.polygon-6-6 {
  position: absolute;
  -webkit-clip-path: polygon(25% 0, 75% 0, 100% 50%, 75% 100%, 25% 100%, 0 50%);
  clip-path: polygon(25% 0, 75% 0, 100% 50%, 75% 100%, 25% 100%, 0 50%);
  width: 200px;
  height: 200px;
  overflow: hidden;
  margin-top: 200px;
  margin-left: 300px;
  transition: 0.2s;
}

.polygon-6-6:hover {
  /* border: 2px solid blue; */
  transform: scale(1.1, 1.1);
  z-index: 2;
}

.polygon-6-7 {
  position: absolute;
  -webkit-clip-path: polygon(25% 0, 75% 0, 100% 50%, 75% 100%, 25% 100%, 0 50%);
  clip-path: polygon(25% 0, 75% 0, 100% 50%, 75% 100%, 25% 100%, 0 50%);
  width: 200px;
  height: 200px;
  overflow: hidden;
  margin-left: 150px;
  margin-top: 300px;
  transition: 0.2s;
}

.polygon-6-7:hover {
  /* border: 2px solid blue; */
  transform: scale(1.1, 1.1);
  z-index: 2;
}

.polygon-6-8 {
  position: absolute;
  -webkit-clip-path: polygon(25% 0, 75% 0, 100% 50%, 75% 100%, 25% 100%, 0 50%);
  clip-path: polygon(25% 0, 75% 0, 100% 50%, 75% 100%, 25% 100%, 0 50%);
  width: 200px;
  height: 200px;
  overflow: hidden;
  margin-top: 300px;
  margin-left: 450px;
  transition: 0.2s;
}

.polygon-6-8:hover {
  /* border: 2px solid blue; */
  transform: scale(1.1, 1.1);
  z-index: 2;
}
</style>
