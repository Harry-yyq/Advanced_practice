package com.star.controller;

import com.star.controller.viewobject.ArticleVO;
import com.star.controller.viewobject.TagVO;
import com.star.error.BusinessException;
import com.star.error.EmBusinessError;
import com.star.response.CommonReturnType;
import com.star.service.ArticleService;
import com.star.service.ArticletagService;
import com.star.service.TagService;
import com.star.service.model.ArticleModel;
import com.star.service.model.TagModel;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

@Controller("tag")
@RequestMapping("/tag")
@CrossOrigin(allowCredentials = "true", allowedHeaders = "*")
public class TagController extends BaseController {
    @Autowired
    private TagService tagService;

    @Autowired
    private ArticletagService articletagService;

    @RequestMapping(value = "/create", method = {RequestMethod.POST}, consumes = {CONTENT_TYPE_FORMED})
    @ResponseBody
    public CommonReturnType createTag(@RequestParam(name="tagName") String tagName) throws BusinessException {
        TagModel tagModel = new TagModel();
        tagModel.setTagName(tagName);

        tagModel = tagService.createTag(tagModel);

        TagVO tagVO = convertFromModel(tagModel);
        return CommonReturnType.create(tagVO);
    }

    @RequestMapping(value = "/delete", method = {RequestMethod.POST})
    @ResponseBody
    public String deleteTag(@RequestParam(name="tagId") Integer tagId){
        articletagService.deleteArticletagByTag(tagId);
        tagService.deleteTag(tagId);
        System.out.println("delete controller");
        return "success";
    }

    @RequestMapping("/get")
    @ResponseBody
    public CommonReturnType getTag(@RequestParam(name="tagId") Integer tagId) throws BusinessException{
        TagModel tagModel = tagService.getTagById(tagId);
        if(tagModel == null){
            throw new BusinessException(EmBusinessError.TAG_NOT_EXIST);
        }
        TagVO tagVO = convertFromModel(tagModel);

        return CommonReturnType.create(tagVO);
    }

    @RequestMapping(value = "/list", method = {RequestMethod.GET})
    @ResponseBody
    public CommonReturnType listTag(){
        List<TagModel> tagModelList = tagService.listTag();

        List<TagVO> tagVOList = tagModelList.stream().map(tagModel -> {
            TagVO tagVO = convertFromModel(tagModel);
            return tagVO;
        }).collect(Collectors.toList());

        return CommonReturnType.create(tagVOList);
    }

    private TagVO convertFromModel(TagModel tagModel){
        if(tagModel == null){
            return null;
        }

        TagVO tagVO = new TagVO();
        BeanUtils.copyProperties(tagModel, tagVO);

        return tagVO;
    }
}
