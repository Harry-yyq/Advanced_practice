package com.star.controller.viewobject;

public class ArticlelikeVO {
    private Integer articlelikeId;
    private Integer articleId;
    private Integer userId;

    public Integer getArticlelikeId() {
        return articlelikeId;
    }

    public void setArticlelikeId(Integer articlelikeId) {
        this.articlelikeId = articlelikeId;
    }

    public Integer getArticleId() {
        return articleId;
    }

    public void setArticleId(Integer articleId) {
        this.articleId = articleId;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }
}
