package com.star.controller;

import com.star.controller.viewobject.CommentVO;
import com.star.error.BusinessException;
import com.star.error.EmBusinessError;
import com.star.response.CommonReturnType;
import com.star.service.CommentService;
import com.star.service.model.CommentModel;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

@Controller("comment")
@RequestMapping("/comment")
@CrossOrigin(allowCredentials = "true", allowedHeaders = "*")
public class CommentController extends BaseController {
    @Autowired
    private CommentService commentService;

    @RequestMapping(value = "/create", method = {RequestMethod.POST}, consumes = {CONTENT_TYPE_FORMED})
    @ResponseBody
    public CommonReturnType createComment(@RequestParam(name="commentContent") String commentContent,
                                          @RequestParam(name="commentDate") Date commentDate,
                                          @RequestParam(name="userId") Integer userId,
                                          @RequestParam(name="articleId") Integer articleId) throws BusinessException {
        CommentModel commentModel = new CommentModel();
        commentModel.setCommentContent(commentContent);
        commentModel.setCommentDate(commentDate);
        commentModel.setUserId(userId);
        commentModel.setArticleId(articleId);

        commentModel = commentService.createComment(commentModel);

        CommentVO commentVO = convertFromModel(commentModel);
        return CommonReturnType.create(commentVO);
    }

    @RequestMapping(value = "/delete", method = {RequestMethod.POST})
    @ResponseBody
    public String deleteComment(@RequestParam(name="commentId") Integer commentId){
        commentService.deleteComment(commentId);
        System.out.println("delete controller");
        return "success";
    }

    @RequestMapping(value = "/count", method = {RequestMethod.GET})
    @ResponseBody
    public int countComment(@RequestParam(name="articleId") Integer articleId){
        return commentService.countComment(articleId);
    }

    @RequestMapping("/get")
    @ResponseBody
    public CommonReturnType getComment(@RequestParam(name="commentId") Integer commentId) throws BusinessException{
        CommentModel commentModel = commentService.getCommentById(commentId);
        if(commentModel == null){
            throw new BusinessException(EmBusinessError.COMMENT_NOT_EXIST);
        }
        CommentVO commentVO = convertFromModel(commentModel);

        return CommonReturnType.create(commentVO);
    }

    @RequestMapping(value = "/listbyarticle", method = {RequestMethod.GET})
    @ResponseBody
    public CommonReturnType listCommentByArticle(@RequestParam(name="articleId") Integer articleId){
        List<CommentModel> commentByArticleModelList = commentService.listCommentByArticle(articleId);

        List<CommentVO> commentByArticleVOList = commentByArticleModelList.stream().map(commentByArticleModel -> {
            CommentVO commentByArticleVO = convertFromModel(commentByArticleModel);
            return commentByArticleVO;
        }).collect(Collectors.toList());

        return CommonReturnType.create(commentByArticleVOList);
    }

    @RequestMapping(value = "/listbyuser", method = {RequestMethod.GET})
    @ResponseBody
    public CommonReturnType listCommentByUser(@RequestParam(name="userId") Integer userId){
        List<CommentModel> commentByUserModelList = commentService.listCommentByUser(userId);

        List<CommentVO> commentByUserVOList = commentByUserModelList.stream().map(commentByUserModel -> {
            CommentVO commentByUserVO = convertFromModel(commentByUserModel);
            return commentByUserVO;
        }).collect(Collectors.toList());

        return CommonReturnType.create(commentByUserVOList);
    }

    private CommentVO convertFromModel(CommentModel commentModel){
        if(commentModel == null){
            return null;
        }

        CommentVO commentVO = new CommentVO();
        BeanUtils.copyProperties(commentModel, commentVO);

        return commentVO;
    }
}
