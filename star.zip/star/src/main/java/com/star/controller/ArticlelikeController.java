package com.star.controller;

import com.star.controller.viewobject.ArticlelikeVO;
import com.star.error.BusinessException;
import com.star.error.EmBusinessError;
import com.star.response.CommonReturnType;
import com.star.service.ArticlelikeService;
import com.star.service.model.ArticlelikeModel;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

@Controller("articlelike")
@RequestMapping("/articlelike")
@CrossOrigin(allowCredentials = "true", allowedHeaders = "*")
public class ArticlelikeController extends BaseController{
    @Autowired
    private ArticlelikeService articlelikeService;

    @RequestMapping(value = "/create", method = {RequestMethod.POST}, consumes = {CONTENT_TYPE_FORMED})
    @ResponseBody
    public CommonReturnType createArticlelike(@RequestParam(name="articleId") Integer articleId,
                                             @RequestParam(name="userId") Integer userId) throws BusinessException {
        ArticlelikeModel articlelikeModel = new ArticlelikeModel();
        articlelikeModel.setArticleId(articleId);
        articlelikeModel.setUserId(userId);

        articlelikeModel = articlelikeService.createArticlelike(articlelikeModel);

        ArticlelikeVO articlelikeVO = convertFromModel(articlelikeModel);
        return CommonReturnType.create(articlelikeVO);
    }

    @RequestMapping(value = "/delete", method = {RequestMethod.POST})
    @ResponseBody
    public String deleteArticlelike(@RequestParam(name="articleId") Integer articleId,
                                   @RequestParam(name="userId") Integer userId){
        articlelikeService.deleteArticlelike(articleId,userId);
        System.out.println("delete controller");
        return "success";
    }

    @RequestMapping("/get")
    @ResponseBody
    public CommonReturnType getArticlelike(@RequestParam(name="articlelikeId") Integer articlelikeId) throws BusinessException{
        ArticlelikeModel articlelikeModel = articlelikeService.getArticlelikeById(articlelikeId);
        if(articlelikeModel == null){
            throw new BusinessException(EmBusinessError.ARTICLELIKE_NOT_EXIST);
        }
        ArticlelikeVO articlelikeVO = convertFromModel(articlelikeModel);

        return CommonReturnType.create(articlelikeVO);
    }

    @RequestMapping(value = "/count", method = {RequestMethod.GET})
    @ResponseBody
    public int countArticlelike(@RequestParam(name="articleId") Integer articleId){
        return articlelikeService.countArticlelike(articleId);
    }

    private ArticlelikeVO convertFromModel(ArticlelikeModel articlelikeModel){
        if(articlelikeModel == null){
            return null;
        }

        ArticlelikeVO articlelikeVO = new ArticlelikeVO();
        BeanUtils.copyProperties(articlelikeModel, articlelikeVO);

        return articlelikeVO;
    }
}
