package com.star.controller;

import com.star.controller.viewobject.ReportVO;
import com.star.error.BusinessException;
import com.star.error.EmBusinessError;
import com.star.response.CommonReturnType;
import com.star.service.ReportService;
import com.star.service.model.ReportModel;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

@Controller("report")
@RequestMapping("/report")
@CrossOrigin(allowCredentials = "true", allowedHeaders = "*")
public class ReportController extends BaseController{
    @Autowired
    private ReportService reportService;

    @RequestMapping(value = "/create", method = {RequestMethod.POST}, consumes = {CONTENT_TYPE_FORMED})
    @ResponseBody
    public CommonReturnType createReport(@RequestParam(name="reportTitle") String reportTitle,
                                          @RequestParam(name="reportContent") String reportContent,
                                          @RequestParam(name="reportDate") Date reportDate) throws BusinessException {
        ReportModel reportModel = new ReportModel();
        reportModel.setReportTitle(reportTitle);
        reportModel.setReportContent(reportContent);
        reportModel.setReportDate(reportDate);

        reportModel = reportService.createReport(reportModel);

        ReportVO reportVO = convertFromModel(reportModel);
        return CommonReturnType.create(reportVO);
    }

    @RequestMapping(value = "/delete", method = {RequestMethod.POST})
    @ResponseBody
    public String deleteReport(@RequestParam(name="reportId") Integer reportId){
        reportService.deleteReport(reportId);
        System.out.println("delete controller");
        return "success";
    }

    @RequestMapping("/get")
    @ResponseBody
    public CommonReturnType getReport(@RequestParam(name="reportId") Integer reportId) throws BusinessException{
        ReportModel reportModel = reportService.getReportById(reportId);
        if(reportModel == null){
            throw new BusinessException(EmBusinessError.REPORT_NOT_EXIST);
        }
        ReportVO reportVO = convertFromModel(reportModel);

        return CommonReturnType.create(reportVO);
    }

    @RequestMapping(value = "/list", method = {RequestMethod.GET})
    @ResponseBody
    public CommonReturnType listReport(){
        List<ReportModel> reportModelList = reportService.listReport();

        List<ReportVO> reportVOList = reportModelList.stream().map(reportModel -> {
            ReportVO reportVO = convertFromModel(reportModel);
            return reportVO;
        }).collect(Collectors.toList());

        return CommonReturnType.create(reportVOList);
    }

    private ReportVO convertFromModel(ReportModel reportModel){
        if(reportModel == null){
            return null;
        }

        ReportVO reportVO = new ReportVO();
        BeanUtils.copyProperties(reportModel, reportVO);

        return reportVO;
    }
}
