package com.star.controller;

import com.alibaba.druid.util.StringUtils;
import com.star.controller.viewobject.UserVO;
import com.star.error.BusinessException;
import com.star.error.EmBusinessError;
import com.star.response.CommonReturnType;
import com.star.service.UserService;
import com.star.service.model.UserModel;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import sun.misc.BASE64Encoder;

import javax.servlet.http.HttpServletRequest;
import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Random;

@Controller("user")
@RequestMapping("/user")
@CrossOrigin(allowCredentials = "true", allowedHeaders = "*")
public class UserController extends BaseController{

    @Autowired
    private UserService userService;

    @Autowired
    private HttpServletRequest httpServletRequest;

    @RequestMapping("/get")
    @ResponseBody
    public CommonReturnType getUser(@RequestParam(name="userId") Integer userId) throws BusinessException{
        UserModel userModel = userService.getUserById(userId);

        if(userModel == null){
//            userModel.setEncrptPassword("123");
            throw new BusinessException(EmBusinessError.USER_NOT_EXIST);
        }

        UserVO userVO = convertFromModel(userModel);

        return CommonReturnType.create(userVO);
    }

    //生成验证码
    @RequestMapping(value = "/getotp", method = {RequestMethod.POST})
    @ResponseBody
    public CommonReturnType getOtp(@RequestParam(name="userPhone") String userPhone){
        // 生成 otp 验证码
        Random random = new Random();
        int randomInt = random.nextInt(99999);
        randomInt += 10000;
        String otpCode = String.valueOf(randomInt);

        // 将 otp 验证码同对应的用户关联 (暂时使用 httpsession 的方式绑定 otp 与手机号)
        httpServletRequest.getSession().setAttribute(userPhone, otpCode);

        // 将 otp 验证码通过短信通道发送给用户 (省略，使用控制台输出代替)
        System.out.println(String.format("userPhone = %s & otpCode = %s", userPhone, otpCode));

        return CommonReturnType.create(null);
    }

    //用户注册
    @RequestMapping(value = "/register", method = {RequestMethod.POST})
    @ResponseBody
    public CommonReturnType register(@RequestParam(name="userName") String userName,
                                     @RequestParam(name="userGender") Integer userGender,
                                     @RequestParam(name="userAge") Integer userAge,
                                     @RequestParam(name="userPassword") String userPassword,
                                     @RequestParam(name="userPhone") String userPhone,
                                     @RequestParam(name="otpCode") String otpCode)
            throws BusinessException, UnsupportedEncodingException, NoSuchAlgorithmException {

        String inSessionOtpCode = (String)this.httpServletRequest.getSession().getAttribute(userPhone);
        if(!StringUtils.equals(otpCode, inSessionOtpCode)){
            throw new BusinessException(EmBusinessError.PARAMETER_VALIDATION_ERROR, "短信验证码不正确");
        }

        UserModel userModel = new UserModel();
        userModel.setUserName(userName);
        userModel.setUserAge(userAge);
        userModel.setUserGender(new Integer(String.valueOf(userGender)));
        userModel.setUserPassword(EncodeByMd5(userPassword));
        userModel.setUserPhone(userPhone);
        userService.register(userModel);

        return CommonReturnType.create(null);
    }

    //MD5加密
    private String EncodeByMd5(String str) throws UnsupportedEncodingException, NoSuchAlgorithmException {
        MessageDigest md5 = MessageDigest.getInstance("MD5");
        BASE64Encoder base64Encoder = new BASE64Encoder();
        String newstr = base64Encoder.encode(md5.digest(str.getBytes("utf-8")));
        return newstr;
    }

    //用户登录
    @RequestMapping(value = "/login", method = {RequestMethod.POST}, consumes = {CONTENT_TYPE_FORMED})
    @ResponseBody
    public CommonReturnType login(@RequestParam(name="userPhone") String userPhone,
                                  @RequestParam(name="userPassword") String userPassword)
            throws BusinessException, UnsupportedEncodingException, NoSuchAlgorithmException {

        if(StringUtils.isEmpty(userPhone) || StringUtils.isEmpty(userPassword)){
            throw new BusinessException(EmBusinessError.PARAMETER_VALIDATION_ERROR);
        }

        UserModel userModel = userService.login(userPhone, EncodeByMd5(userPassword));
        userService.updateLogin(1,userPhone);
        httpServletRequest.getSession().setAttribute("LOGIN", true);
        httpServletRequest.getSession().setAttribute("LOGIN_USER", userModel);

        return CommonReturnType.create(null);
    }

    //用户登出
    @RequestMapping(value = "/logout", method = {RequestMethod.POST}, consumes = {CONTENT_TYPE_FORMED})
    @ResponseBody
    public String logout(@RequestParam(name="userPhone") String userPhone)
            throws BusinessException, UnsupportedEncodingException, NoSuchAlgorithmException {
        userService.updateLogin(0,userPhone);
        return "success";
    }

    //修改角色权限位
    @RequestMapping(value = "/worker", method = {RequestMethod.POST}, consumes = {CONTENT_TYPE_FORMED})
    @ResponseBody
    public String worker(@RequestParam(name="userId") Integer userId,
                                  @RequestParam(name="userWorker") Integer userWorker)
            throws BusinessException, UnsupportedEncodingException, NoSuchAlgorithmException {
        userService.updateWorker(userWorker,userId);
        return "success";
    }

    private UserVO convertFromModel(UserModel userModel){
        if(userModel == null){
            return null;
        }
        UserVO userVO = new UserVO();
        BeanUtils.copyProperties(userModel, userVO);
        return userVO;
    }
}