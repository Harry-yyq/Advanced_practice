package com.star.controller;

import com.star.controller.viewobject.CompanyVO;
import com.star.error.BusinessException;
import com.star.error.EmBusinessError;
import com.star.response.CommonReturnType;
import com.star.service.CompanyService;
import com.star.service.model.CompanyModel;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@Controller("company")
@RequestMapping("/company")
@CrossOrigin(allowCredentials = "true", allowedHeaders = "*")
public class CompanyController extends BaseController{
    @Autowired
    private CompanyService companyService;

    @RequestMapping(value = "/create", method = {RequestMethod.POST}, consumes = {CONTENT_TYPE_FORMED})
    @ResponseBody
    public CommonReturnType createCompany(@RequestParam(name="companyIntro") String companyIntro) throws BusinessException {
        CompanyModel companyModel = new CompanyModel();
        companyModel.setCompanyIntro(companyIntro);

        companyModel = companyService.createCompany(companyModel);

        CompanyVO companyVO = convertFromModel(companyModel);
        return CommonReturnType.create(companyVO);
    }

    @RequestMapping(value = "/delete", method = {RequestMethod.POST})
    @ResponseBody
    public String deleteCompany(@RequestParam(name="companyId") Integer companyId){
        companyService.deleteCompany(companyId);
        System.out.println("delete controller");
        return "success";
    }

    @RequestMapping("/get")
    @ResponseBody
    public CommonReturnType getCompany(@RequestParam(name="companyId") Integer companyId) throws BusinessException{
        CompanyModel companyModel = companyService.getCompanyById(companyId);
        if(companyModel == null){
            throw new BusinessException(EmBusinessError.COMPANY_NOT_EXIST);
        }
        CompanyVO companyVO = convertFromModel(companyModel);

        return CommonReturnType.create(companyVO);
    }

    @RequestMapping(value = "/list", method = {RequestMethod.GET})
    @ResponseBody
    public CommonReturnType listCompany(){
        List<CompanyModel> companyModelList = companyService.listCompany();

        List<CompanyVO> companyVOList = companyModelList.stream().map(companyModel -> {
            CompanyVO companyVO = convertFromModel(companyModel);
            return companyVO;
        }).collect(Collectors.toList());

        return CommonReturnType.create(companyVOList);
    }
    private CompanyVO convertFromModel(CompanyModel companyModel){
        if(companyModel == null){
            return null;
        }

        CompanyVO companyVO = new CompanyVO();
        BeanUtils.copyProperties(companyModel, companyVO);

        return companyVO;
    }
}
