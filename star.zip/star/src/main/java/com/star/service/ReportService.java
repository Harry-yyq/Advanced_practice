package com.star.service;

import com.star.error.BusinessException;
import com.star.service.model.ReportModel;

import java.util.List;

public interface ReportService {
    ReportModel getReportById(Integer id);
    ReportModel createReport(ReportModel reportModel) throws BusinessException;
    List<ReportModel> listReport();
    void deleteReport(Integer id);
}
