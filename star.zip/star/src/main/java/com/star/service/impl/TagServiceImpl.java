package com.star.service.impl;

import com.star.dao.TagDOMapper;
import com.star.dataobject.TagDO;
import com.star.error.BusinessException;
import com.star.service.TagService;
import com.star.service.model.TagModel;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class TagServiceImpl implements TagService {
    @Autowired
    private TagDOMapper tagDOMapper;

    @Override
    public TagModel getTagById(Integer tagId){
        TagDO tagDO = tagDOMapper.selectByPrimaryKey(tagId);

        if(tagDO == null){
            return null;
        }

        TagModel tagModel = convertFromDataObject(tagDO);

        return tagModel;
    }

    @Override
    @Transactional
    public TagModel createTag(TagModel tagModel) throws BusinessException {
        TagDO tagDO = convertFromModel(tagModel);
        tagDOMapper.insertSelective(tagDO);

        tagModel.setTagId(tagDO.getTagId());

        return getTagById(tagModel.getTagId());
    }

    @Override
    public List<TagModel> listTag() {
        List<TagDO> tagDOList = tagDOMapper.listTag();

        List<TagModel> tagModelList = tagDOList.stream().map(tagDO -> {
            TagModel tagModel = convertFromDataObject(tagDO);
            return tagModel;
        }).collect(Collectors.toList());
        return tagModelList;
    }

    @Override
    public void deleteTag(Integer tagId){
        tagDOMapper.deleteByPrimaryKey(tagId);
    }

    private TagDO convertFromModel(TagModel tagModel){
        if(tagModel == null){
            return null;
        }

        TagDO tagDO = new TagDO();
        BeanUtils.copyProperties(tagModel, tagDO);

        return tagDO;
    }

    private TagModel convertFromDataObject(TagDO tagDO){
        if(tagDO == null){
            return null;
        }

        TagModel tagModel = new TagModel();
        BeanUtils.copyProperties(tagDO, tagModel);

        return tagModel;
    }
}
