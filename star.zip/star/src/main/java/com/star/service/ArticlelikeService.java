package com.star.service;

import com.star.error.BusinessException;
import com.star.service.model.ArticlelikeModel;

public interface ArticlelikeService {
    ArticlelikeModel getArticlelikeById(Integer id);
    ArticlelikeModel createArticlelike(ArticlelikeModel articlelikeModel) throws BusinessException;
    void deleteArticlelike(Integer articleId,Integer userId);
    int countArticlelike(Integer articleId);
}
