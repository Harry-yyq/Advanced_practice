package com.star.service;

import com.star.error.BusinessException;
import com.star.service.model.UserModel;

public interface UserService {
    UserModel getUserById(Integer id);
    void register(UserModel userModel) throws BusinessException;
    UserModel login(String userPhone, String userPassword) throws BusinessException;
    void updateWorker(Integer userWorker, Integer id);
    void updateLogin(Integer userLogin, String userPhone);
}
