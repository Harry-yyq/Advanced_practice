package com.star.service;

import com.star.error.BusinessException;
import com.star.service.model.ArticletagModel;

import java.util.List;

public interface ArticletagService {
    ArticletagModel getArticletagById(Integer id);
    ArticletagModel createArticletag(ArticletagModel articletagModel) throws BusinessException;
    List<ArticletagModel> listTagByArticle(Integer articleId);
    List<ArticletagModel> listArticleByTag(Integer tagId);
    void deleteArticletagByArticle(Integer articleId);
    void deleteArticletagByTag(Integer tagId);
    void deleteArticletagByTwo(Integer articleId,Integer tagId);
}