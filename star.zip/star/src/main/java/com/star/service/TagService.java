package com.star.service;

import com.star.error.BusinessException;
import com.star.service.model.TagModel;

import java.util.List;

public interface TagService {
    TagModel getTagById(Integer id);
    TagModel createTag(TagModel tagModel) throws BusinessException;
    List<TagModel> listTag();
    void deleteTag(Integer id);
}
