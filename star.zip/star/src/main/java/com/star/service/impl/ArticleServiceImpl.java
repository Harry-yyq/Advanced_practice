package com.star.service.impl;

import com.star.dao.ArticleDOMapper;
import com.star.dataobject.ArticleDO;
import com.star.error.BusinessException;
import com.star.service.ArticleService;
import com.star.service.model.ArticleModel;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class ArticleServiceImpl implements ArticleService {
    @Autowired
    private ArticleDOMapper articleDOMapper;

    @Override
    public ArticleModel getArticleById(Integer articleId){
        ArticleDO articleDO = articleDOMapper.selectByPrimaryKey(articleId);

        if(articleDO == null){
            return null;
        }

        ArticleModel articleModel = convertFromDataObject(articleDO);

        return articleModel;
    }

    @Override
    @Transactional
    public ArticleModel createArticle(ArticleModel articleModel) throws BusinessException {
        ArticleDO articleDO = convertFromModel(articleModel);
        articleDOMapper.insertSelective(articleDO);

        articleModel.setArticleId(articleDO.getArticleId());

        return getArticleById(articleModel.getArticleId());
    }

    @Override
    public List<ArticleModel> listArticle() {
        List<ArticleDO> articleDOList = articleDOMapper.listArticle();

        List<ArticleModel> articleModelList = articleDOList.stream().map(articleDO -> {
            ArticleModel articleModel = convertFromDataObject(articleDO);
            return articleModel;
        }).collect(Collectors.toList());
        return articleModelList;
    }

    @Override
    public List<ArticleModel> listArticleByUser(Integer userId){
        List<ArticleDO> articleDOList = articleDOMapper.listArticleByUser(userId);

        List<ArticleModel> articleModelList = articleDOList.stream().map(articleDO -> {
            ArticleModel articleModel = convertFromDataObject(articleDO);
            return articleModel;
        }).collect(Collectors.toList());
        return articleModelList;
    }

    @Override
    public void deleteArticle(Integer articleId){
        articleDOMapper.deleteByPrimaryKey(articleId);
    }

    private ArticleDO convertFromModel(ArticleModel articleModel){
        if(articleModel == null){
            return null;
        }

        ArticleDO articleDO = new ArticleDO();
        BeanUtils.copyProperties(articleModel, articleDO);

        return articleDO;
    }

    private ArticleModel convertFromDataObject(ArticleDO articleDO){
        if(articleDO == null){
            return null;
        }

        ArticleModel articleModel = new ArticleModel();
        BeanUtils.copyProperties(articleDO, articleModel);

        return articleModel;
    }
}
