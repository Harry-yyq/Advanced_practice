package com.star.service;

import com.star.error.BusinessException;
import com.star.service.model.ArticleModel;

import java.util.List;

public interface ArticleService {
    ArticleModel getArticleById(Integer id);
    ArticleModel createArticle(ArticleModel articleModel) throws BusinessException;
    List<ArticleModel> listArticle();
    List<ArticleModel> listArticleByUser(Integer userId);
    void deleteArticle(Integer id);
}
