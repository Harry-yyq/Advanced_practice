package com.star.service.impl;

import com.star.dao.ArticletagDOMapper;
import com.star.dataobject.ArticletagDO;
import com.star.error.BusinessException;
import com.star.service.ArticletagService;
import com.star.service.model.ArticletagModel;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class ArticletagServiceImpl implements ArticletagService {
    @Autowired
    private ArticletagDOMapper articletagDOMapper;

    @Override
    public ArticletagModel getArticletagById(Integer articletagId){
        ArticletagDO articletagDO = articletagDOMapper.selectByPrimaryKey(articletagId);

        if(articletagDO == null){
            return null;
        }

        ArticletagModel articletagModel = convertFromDataObject(articletagDO);

        return articletagModel;
    }

    @Override
    public List<ArticletagModel> listTagByArticle(Integer articleId){
        List<ArticletagDO> articletagDOList = articletagDOMapper.listArticletagByArticle(articleId);

        List<ArticletagModel> articletagModelList = articletagDOList.stream().map(articletagDO -> {
            ArticletagModel articletagModel = convertFromDataObject(articletagDO);
            return articletagModel;
        }).collect(Collectors.toList());
        return articletagModelList;
    }

    @Override
    public List<ArticletagModel> listArticleByTag(Integer tagId){
        List<ArticletagDO> articletagDOList = articletagDOMapper.listArticletagByTag(tagId);

        List<ArticletagModel> articletagModelList = articletagDOList.stream().map(articletagDO -> {
            ArticletagModel articletagModel = convertFromDataObject(articletagDO);
            return articletagModel;
        }).collect(Collectors.toList());
        return articletagModelList;
    }

    @Override
    @Transactional
    public ArticletagModel createArticletag(ArticletagModel articletagModel) throws BusinessException {
        ArticletagDO articletagDO = convertFromModel(articletagModel);
        articletagDOMapper.insertSelective(articletagDO);

        articletagModel.setArticletagId(articletagDO.getArticletagId());

        return getArticletagById(articletagModel.getArticletagId());
    }

    @Override
    public void deleteArticletagByArticle(Integer articleId){
        articletagDOMapper.deleteByArticleKey(articleId);
    }

    @Override
    public void deleteArticletagByTag(Integer tagId){
        articletagDOMapper.deleteByTagKey(tagId);
    }

    @Override
    public void deleteArticletagByTwo(Integer articleId,Integer tagId){
        articletagDOMapper.deleteByTwoKey(articleId,tagId);
    }

    private ArticletagDO convertFromModel(ArticletagModel articletagModel){
        if(articletagModel == null){
            return null;
        }

        ArticletagDO articletagDO = new ArticletagDO();
        BeanUtils.copyProperties(articletagModel, articletagDO);

        return articletagDO;
    }

    private ArticletagModel convertFromDataObject(ArticletagDO articletagDO){
        if(articletagDO == null){
            return null;
        }

        ArticletagModel articletagModel = new ArticletagModel();
        BeanUtils.copyProperties(articletagDO, articletagModel);

        return articletagModel;
    }
}
