package com.star.service.impl;

import com.alibaba.druid.util.StringUtils;
import com.star.dao.UserCodeDOMapper;
import com.star.dao.UserDOMapper;
import com.star.dataobject.UserCodeDO;
import com.star.dataobject.UserDO;
import com.star.error.BusinessException;
import com.star.error.EmBusinessError;
import com.star.service.UserService;
import com.star.service.model.UserModel;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class UserServiceImpl implements UserService {
    @Autowired
    private UserDOMapper userDOMapper;

    @Autowired
    private UserCodeDOMapper userCodeDOMapper;

    @Override
    public UserModel getUserById(Integer id){
        UserDO userDO = userDOMapper.selectByPrimaryKey(id);

        if(userDO == null){
            return null;
        }

        UserCodeDO userCodeDO = userCodeDOMapper.selectByUserId(userDO.getUserId());

        return convertFromDataObject(userDO, userCodeDO);

    }

    @Override
    @Transactional // 事务操作
    public void register(UserModel userModel) throws BusinessException {
        if(userModel == null){
            throw new BusinessException(EmBusinessError.PARAMETER_VALIDATION_ERROR);
        }

        if(StringUtils.isEmpty(userModel.getUserPhone())
                || StringUtils.isEmpty(userModel.getUserName())
                || userModel.getUserGender() == null
                || userModel.getUserAge() == null
                || StringUtils.isEmpty(userModel.getUserPassword())){
            throw new BusinessException(EmBusinessError.PARAMETER_VALIDATION_ERROR);
        }

        UserDO userDO = convertFromModel(userModel);
        try{
            userDOMapper.insertSelective(userDO);
        }catch (DuplicateKeyException ex){
            throw new BusinessException(EmBusinessError.PARAMETER_VALIDATION_ERROR, "手机号码已注册");
        }

        userModel.setUserId(userDO.getUserId()); // 获取自增 id

        UserCodeDO userCodeDO = convertCodeFromModel(userModel);
        userCodeDOMapper.insertSelective(userCodeDO);

        return;
    }

    @Override
    public UserModel login(String userPhone, String userPassword) throws BusinessException {
        UserDO userDO = userDOMapper.selectByUserPhone(userPhone);
        if(userDO == null){
            throw new BusinessException(EmBusinessError.USER_LOGIN_FAIL);
        }
        UserCodeDO userCodeDO = userCodeDOMapper.selectByUserId(userDO.getUserId());
        UserModel userModel = convertFromDataObject(userDO, userCodeDO);
        if(!StringUtils.equals(userPassword, userModel.getUserPassword())){
            throw new BusinessException(EmBusinessError.USER_LOGIN_FAIL);
        }
        return userModel;
    }

    @Override
    public void updateWorker(Integer userWorker,Integer userId){
        userDOMapper.updateWorker(userWorker,userId);
    }

    @Override
    public void updateLogin(Integer userLogin,String userPhone){
        userDOMapper.updateLogin(userLogin,userPhone);
    }

    @Override
    public void updatePassword(String userPassword,Integer userId){
        userCodeDOMapper.updatePassword(userPassword,userId);
    }

    private UserModel convertFromDataObject(UserDO userDO, UserCodeDO userCodeDO){
        if(userDO == null){
            return null;
        }
        UserModel userModel = new UserModel();
        BeanUtils.copyProperties(userDO, userModel);

        if(userCodeDO != null){
            userModel.setUserPassword(userCodeDO.getUserPassword());
        }
        return userModel;
    }

    private UserDO convertFromModel(UserModel userModel){
        if(userModel == null){
            return null;
        }
        UserDO userDO = new UserDO();
        BeanUtils.copyProperties(userModel, userDO);
        return userDO;
    }

    private UserCodeDO convertCodeFromModel(UserModel userModel){
        if(userModel == null){
            return null;
        }
        UserCodeDO userCodeDO = new UserCodeDO();
        userCodeDO.setUserPassword(userModel.getUserPassword());
        userCodeDO.setUserId(userModel.getUserId());
        return userCodeDO;
    }
}
