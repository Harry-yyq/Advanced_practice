package com.star.service.impl;

import com.star.dao.LeaderDOMapper;
import com.star.dataobject.LeaderDO;
import com.star.error.BusinessException;
import com.star.service.LeaderService;
import com.star.service.model.LeaderModel;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class LeaderServiceImpl implements LeaderService {
    @Autowired
    private LeaderDOMapper leaderDOMapper;

    @Override
    public LeaderModel getLeaderById(Integer leaderId){
        LeaderDO leaderDO = leaderDOMapper.selectByPrimaryKey(leaderId);

        if(leaderDO == null){
            return null;
        }

        LeaderModel leaderModel = convertFromDataObject(leaderDO);

        return leaderModel;
    }

    @Override
    @Transactional
    public LeaderModel createLeader(LeaderModel leaderModel) throws BusinessException {
        LeaderDO leaderDO = convertFromModel(leaderModel);
        leaderDOMapper.insertSelective(leaderDO);

        leaderModel.setLeaderId(leaderDO.getLeaderId());

        return getLeaderById(leaderModel.getLeaderId());
    }

    @Override
    public List<LeaderModel> listLeader() {
        List<LeaderDO> leaderDOList = leaderDOMapper.listLeader();

        List<LeaderModel> leaderModelList = leaderDOList.stream().map(leaderDO -> {
            LeaderModel leaderModel = convertFromDataObject(leaderDO);
            return leaderModel;
        }).collect(Collectors.toList());
        return leaderModelList;
    }

    @Override
    public void deleteLeader(Integer leaderId){
        leaderDOMapper.deleteByPrimaryKey(leaderId);
    }

    private LeaderDO convertFromModel(LeaderModel leaderModel){
        if(leaderModel == null){
            return null;
        }

        LeaderDO leaderDO = new LeaderDO();
        BeanUtils.copyProperties(leaderModel, leaderDO);

        return leaderDO;
    }

    private LeaderModel convertFromDataObject(LeaderDO leaderDO){
        if(leaderDO == null){
            return null;
        }

        LeaderModel leaderModel = new LeaderModel();
        BeanUtils.copyProperties(leaderDO, leaderModel);

        return leaderModel;
    }
}
