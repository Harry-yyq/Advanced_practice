package com.shop.controller;

import com.shop.model.Order;
import com.shop.response.Response;
import com.shop.service.GoodsService;
import com.shop.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/shop/order")
@CrossOrigin
public class OrderController {

    @Autowired
    private OrderService orderService;

    @Autowired
    private GoodsService goodsService;

    @GetMapping("getUserOrder")
    public Response getAllOrderByUserId(@RequestParam(name="userId") String id) {
        List<Order> orders = orderService.findOrderByUserId(id);
        if(orders.size() == 0) {
            return Response.create("none", "fail");
        }
        return Response.create(orders, "success");
    }

    @GetMapping("geAllOrder")
    public Response getAllOrder() {
        List<Order> orders = orderService.findAll();
        if(orders.size() == 0) {
            return Response.create("none", "fail");
        }
        return Response.create(orders, "success");
    }

    @PostMapping("createOrder")
    public Response createOneOrder(@RequestParam(name="userId") String userId, @RequestParam(name="price")
                                    String price, @RequestParam(name="goodsId")String goodsId,
                                   @RequestParam(name="date")String date, @RequestParam(name="actualPrice")
                                   String actualPrice, @RequestParam(name="totalPrice")String totalPrice,
                                   @RequestParam(name="num")String num) {
        Order order = orderService.createOneOrder(userId, price, goodsId, date, actualPrice, totalPrice, num);
        return Response.create(order, "success");
    }

}
