package com.star.service.impl;

import com.star.dao.CommentDOMapper;
import com.star.dataobject.CommentDO;
import com.star.error.BusinessException;
import com.star.service.CommentService;
import com.star.service.model.CommentModel;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class CommentServiceImpl implements CommentService {
    @Autowired
    private CommentDOMapper commentDOMapper;

    @Override
    public CommentModel getCommentById(Integer commentId){
        CommentDO commentDO = commentDOMapper.selectByPrimaryKey(commentId);

        if(commentDO == null){
            return null;
        }

        CommentModel commentModel = convertFromDataObject(commentDO);

        return commentModel;
    }

    @Override
    @Transactional
    public CommentModel createComment(CommentModel commentModel) throws BusinessException {
        CommentDO commentDO = convertFromModel(commentModel);
        commentDOMapper.insertSelective(commentDO);

        commentModel.setCommentId(commentDO.getCommentId());

        return getCommentById(commentModel.getCommentId());
    }

    @Override
    public List<CommentModel> listCommentByArticle(Integer articleId){
        List<CommentDO> commentDOList = commentDOMapper.listCommentByArticle(articleId);

        List<CommentModel> commentModelList = commentDOList.stream().map(commentDO -> {
            CommentModel commentModel = convertFromDataObject(commentDO);
            return commentModel;
        }).collect(Collectors.toList());
        return commentModelList;
    }

    @Override
    public List<CommentModel> listCommentByUser(Integer userId){
        List<CommentDO> commentDOList = commentDOMapper.listCommentByUser(userId);

        List<CommentModel> commentModelList = commentDOList.stream().map(commentDO -> {
            CommentModel commentModel = convertFromDataObject(commentDO);
            return commentModel;
        }).collect(Collectors.toList());
        return commentModelList;
    }

    @Override
    public void deleteComment(Integer commentId){
        commentDOMapper.deleteByPrimaryKey(commentId);
    }

    @Override
    public int countComment(Integer articleId){
        return commentDOMapper.countByArticleKey(articleId);
    }

    private CommentDO convertFromModel(CommentModel commentModel){
        if(commentModel == null){
            return null;
        }

        CommentDO commentDO = new CommentDO();
        BeanUtils.copyProperties(commentModel, commentDO);

        return commentDO;
    }

    private CommentModel convertFromDataObject(CommentDO commentDO){
        if(commentDO == null){
            return null;
        }

        CommentModel commentModel = new CommentModel();
        BeanUtils.copyProperties(commentDO, commentModel);

        return commentModel;
    }

}
