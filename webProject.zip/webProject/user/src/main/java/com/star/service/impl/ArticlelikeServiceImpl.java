package com.star.service.impl;

import com.star.dao.ArticlelikeDOMapper;
import com.star.dataobject.ArticlelikeDO;
import com.star.error.BusinessException;
import com.star.service.ArticlelikeService;
import com.star.service.model.ArticlelikeModel;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class ArticlelikeServiceImpl implements ArticlelikeService {
    @Autowired
    private ArticlelikeDOMapper articlelikeDOMapper;

    @Override
    public ArticlelikeModel getArticlelikeById(Integer articlelikeId){
        ArticlelikeDO articlelikeDO = articlelikeDOMapper.selectByPrimaryKey(articlelikeId);

        if(articlelikeDO == null){
            return null;
        }

        ArticlelikeModel articlelikeModel = convertFromDataObject(articlelikeDO);

        return articlelikeModel;
    }

    @Override
    @Transactional
    public ArticlelikeModel createArticlelike(ArticlelikeModel articlelikeModel) throws BusinessException {
        ArticlelikeDO articlelikeDO = convertFromModel(articlelikeModel);
        articlelikeDOMapper.insertSelective(articlelikeDO);

        articlelikeModel.setArticlelikeId(articlelikeDO.getArticlelikeId());

        return getArticlelikeById(articlelikeModel.getArticlelikeId());
    }

    @Override
    public void deleteArticlelike(Integer articleId,Integer userId){
        articlelikeDOMapper.deleteByTwoKey(articleId,userId);
    }

    @Override
    public int countArticlelike(Integer articleId){
        return articlelikeDOMapper.countByArticleKey(articleId);
    }

    private ArticlelikeDO convertFromModel(ArticlelikeModel articlelikeModel){
        if(articlelikeModel == null){
            return null;
        }

        ArticlelikeDO articlelikeDO = new ArticlelikeDO();
        BeanUtils.copyProperties(articlelikeModel, articlelikeDO);

        return articlelikeDO;
    }

    private ArticlelikeModel convertFromDataObject(ArticlelikeDO articlelikeDO){
        if(articlelikeDO == null){
            return null;
        }

        ArticlelikeModel articlelikeModel = new ArticlelikeModel();
        BeanUtils.copyProperties(articlelikeDO, articlelikeModel);

        return articlelikeModel;
    }
}
