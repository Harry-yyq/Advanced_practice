package com.star.service.impl;

import com.star.dao.CompanyDOMapper;
import com.star.dataobject.CompanyDO;
import com.star.error.BusinessException;
import com.star.service.CompanyService;
import com.star.service.model.CompanyModel;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class CompanyServiceImpl implements CompanyService {
    @Autowired
    private CompanyDOMapper companyDOMapper;

    @Override
    public CompanyModel getCompanyById(Integer companyId){
        CompanyDO companyDO = companyDOMapper.selectByPrimaryKey(companyId);

        if(companyDO == null){
            return null;
        }

        CompanyModel companyModel = convertFromDataObject(companyDO);

        return companyModel;
    }

    @Override
    @Transactional
    public CompanyModel createCompany(CompanyModel companyModel) throws BusinessException {
        CompanyDO companyDO = convertFromModel(companyModel);
        companyDOMapper.insertSelective(companyDO);

        companyModel.setCompanyId(companyDO.getCompanyId());

        return getCompanyById(companyModel.getCompanyId());
    }

    @Override
    public List<CompanyModel> listCompany() {
        List<CompanyDO> companyDOList = companyDOMapper.listCompany();

        List<CompanyModel> companyModelList = companyDOList.stream().map(companyDO -> {
            CompanyModel companyModel = convertFromDataObject(companyDO);
            return companyModel;
        }).collect(Collectors.toList());
        return companyModelList;
    }

    @Override
    public void deleteCompany(Integer companyId){
        companyDOMapper.deleteByPrimaryKey(companyId);
    }

    private CompanyDO convertFromModel(CompanyModel companyModel){
        if(companyModel == null){
            return null;
        }

        CompanyDO companyDO = new CompanyDO();
        BeanUtils.copyProperties(companyModel, companyDO);

        return companyDO;
    }

    private CompanyModel convertFromDataObject(CompanyDO companyDO){
        if(companyDO == null){
            return null;
        }

        CompanyModel companyModel = new CompanyModel();
        BeanUtils.copyProperties(companyDO, companyModel);

        return companyModel;
    }
}
