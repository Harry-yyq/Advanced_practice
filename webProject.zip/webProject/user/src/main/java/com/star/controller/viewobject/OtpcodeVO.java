package com.star.controller.viewobject;

public class OtpcodeVO {
    public String otpCode;

    public String getOtpCode() {
        return otpCode;
    }

    public void setOtpCode(String otpCode) {
        this.otpCode = otpCode == null ? null : otpCode.trim();
    }

}
