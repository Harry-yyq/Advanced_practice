package com.star.service;

import com.star.error.BusinessException;
import com.star.service.model.CompanyModel;

import java.util.List;

public interface CompanyService {
    CompanyModel getCompanyById(Integer id);
    CompanyModel createCompany(CompanyModel companyModel) throws BusinessException;
    List<CompanyModel> listCompany();
    void deleteCompany(Integer id);
}
