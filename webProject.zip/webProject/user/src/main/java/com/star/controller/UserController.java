package com.star.controller;

import com.alibaba.druid.util.StringUtils;
import com.star.controller.viewobject.ArticleVO;
import com.star.controller.viewobject.OtpcodeVO;
import com.star.controller.viewobject.UserVO;
import com.star.error.BusinessException;
import com.star.error.EmBusinessError;
import com.star.response.CommonReturnType;
import com.star.service.UserService;
import com.star.service.model.ArticleModel;
import com.star.service.model.UserModel;
import com.star.write.Writelog;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import sun.misc.BASE64Encoder;

import javax.servlet.http.HttpServletRequest;
import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.List;
import java.util.Random;
import java.util.stream.Collectors;

@Controller("user")
@RequestMapping("/user")
@CrossOrigin(allowCredentials = "true", allowedHeaders = "*")
public class UserController extends BaseController{

    @Autowired
    private UserService userService;

    @Autowired
    private HttpServletRequest httpServletRequest;

    @RequestMapping("/get")
    @ResponseBody
    public CommonReturnType getUser(@RequestParam(name="userId") Integer userId) throws BusinessException{
        UserModel userModel = userService.getUserById(userId);

        if(userModel == null){
            throw new BusinessException(EmBusinessError.USER_NOT_EXIST);
        }

        UserVO userVO = convertFromModel(userModel);
        Writelog writelog = new Writelog();
        writelog.saveAsFileWriter("get the user");
        return CommonReturnType.create(userVO);
    }

    @RequestMapping(value = "/list", method = {RequestMethod.GET})
    @ResponseBody
    public CommonReturnType listUser(){
        List<UserModel> userModelList = userService.listUser();

        List<UserVO> userVOList = userModelList.stream().map(userModel -> {
            UserVO userVO = convertFromModel(userModel);
            return userVO;
        }).collect(Collectors.toList());
        Writelog writelog = new Writelog();
        writelog.saveAsFileWriter("list the user");
        return CommonReturnType.create(userVOList);
    }

    //生成验证码
    @RequestMapping(value = "/getotp", method = {RequestMethod.GET})
    @ResponseBody
    public OtpcodeVO getOtp(@RequestParam(name="userPhone") String userPhone){
        // 生成 otp 验证码
        Random random = new Random();
        int randomInt = random.nextInt(99999);
        randomInt += 10000;
        String otpCode = String.valueOf(randomInt);
        // 将 otp 验证码同对应的用户关联 (暂时使用 httpsession 的方式绑定 otp 与手机号)
        httpServletRequest.getSession().setAttribute(userPhone, otpCode);
        String inSessionOtpCode = (String)this.httpServletRequest.getSession().getAttribute(userPhone);
        System.out.println("ins="+inSessionOtpCode);
        // 将 otp 验证码通过短信通道发送给用户 (省略，使用控制台输出代替)
        System.out.println(String.format("userPhone = %s & otpCode = %s", userPhone, otpCode));
        Writelog writelog = new Writelog();
        writelog.saveAsFileWriter("get the otp");
        OtpcodeVO otpcodeVO = new OtpcodeVO();
        otpcodeVO.setOtpCode(otpCode);
        return otpcodeVO;
    }

    //用户注册
    @RequestMapping(value = "/register", method = {RequestMethod.POST})
    @ResponseBody
    public CommonReturnType register(@RequestParam(name="userName",required = false) String userName,
                                     @RequestParam(name="userGender",required = false) Integer userGender,
                                     @RequestParam(name="userAge",required = false) Integer userAge,
                                     @RequestParam(name="userPassword",required = false) String userPassword,
                                     @RequestParam(name="userPhone",required = false) String userPhone,
                                     @RequestParam(name="otpCode",required = false) String otpCode)
            throws BusinessException, UnsupportedEncodingException, NoSuchAlgorithmException {

        String inSessionOtpCode = (String)this.httpServletRequest.getSession().getAttribute(userPhone);
        //if(!StringUtils.equals(otpCode, inSessionOtpCode)){
          //  throw new BusinessException(EmBusinessError.PARAMETER_VALIDATION_ERROR, "短信验证码不正确");
        //}

        UserModel userModel = new UserModel();
        userModel.setUserName(userName);
        userModel.setUserAge(userAge);
        userModel.setUserGender(new Integer(String.valueOf(userGender)));
        userModel.setUserPassword(EncodeByMd5(userPassword));
        userModel.setUserPhone(userPhone);
        userService.register(userModel);
        Writelog writelog = new Writelog();
        writelog.saveAsFileWriter("register the user");
        return CommonReturnType.create(null);
    }

    //MD5加密
    private String EncodeByMd5(String str) throws UnsupportedEncodingException, NoSuchAlgorithmException {
        MessageDigest md5 = MessageDigest.getInstance("MD5");
        BASE64Encoder base64Encoder = new BASE64Encoder();
        String newstr = base64Encoder.encode(md5.digest(str.getBytes("utf-8")));
        return newstr;
    }

    //用户登录
    @RequestMapping(value = "/login", method = {RequestMethod.POST}, consumes = {CONTENT_TYPE_FORMED})
    @ResponseBody
    public CommonReturnType login(@RequestParam(name="userPhone",required = false) String userPhone,
                                  @RequestParam(name="userPassword",required = false) String userPassword)
            throws BusinessException, UnsupportedEncodingException, NoSuchAlgorithmException {
        if(StringUtils.isEmpty(userPhone) || StringUtils.isEmpty(userPassword)){
            throw new BusinessException(EmBusinessError.PARAMETER_VALIDATION_ERROR);
        }
        UserModel userModel = userService.login(userPhone, EncodeByMd5(userPassword));
        userService.updateLogin(1,userPhone);
        httpServletRequest.getSession().setAttribute("LOGIN", true);
        httpServletRequest.getSession().setAttribute("LOGIN_USER", userModel);
        UserModel userModel2 = userService.getUserByPhone(userPhone);
        if(userModel2 == null){
            throw new BusinessException(EmBusinessError.USER_NOT_EXIST);
        }
        UserVO userVO = convertFromModel(userModel2);
        Writelog writelog = new Writelog();
        writelog.saveAsFileWriter("login the user");
        return CommonReturnType.create(userVO);
    }

    //用户登出
    @RequestMapping(value = "/logout", method = {RequestMethod.POST}, consumes = {CONTENT_TYPE_FORMED})
    @ResponseBody
    public String logout(@RequestParam(name="userPhone") String userPhone)
            throws BusinessException, UnsupportedEncodingException, NoSuchAlgorithmException {
        userService.updateLogin(0,userPhone);
        Writelog writelog = new Writelog();
        writelog.saveAsFileWriter("logout the user");
        return "success";
    }

    //修改角色权限位
    @RequestMapping(value = "/worker", method = {RequestMethod.POST},consumes = {CONTENT_TYPE_FORMED})
    @ResponseBody
    public String changeWorker(@RequestParam(name="userId",required = false) Integer userId,
                                  @RequestParam(name="userWorker",required = false) Integer userWorker)
            throws BusinessException{
        userService.updateWorker(userWorker,userId);
        Writelog writelog = new Writelog();
        writelog.saveAsFileWriter("change the worker authority");
        return "success";
    }

    //修改密码
    @RequestMapping(value = "/password", method = {RequestMethod.POST}, consumes = {CONTENT_TYPE_FORMED})
    @ResponseBody
    public String changePassword(@RequestParam(name="userId") Integer userId,
                         @RequestParam(name="userPassword") String userPassword)
            throws BusinessException, UnsupportedEncodingException, NoSuchAlgorithmException {
        userService.updatePassword(userPassword,userId);
        Writelog writelog = new Writelog();
        writelog.saveAsFileWriter("change the password");
        return "success";
    }

    private UserVO convertFromModel(UserModel userModel){
        if(userModel == null){
            return null;
        }
        UserVO userVO = new UserVO();
        BeanUtils.copyProperties(userModel, userVO);
        return userVO;
    }
}