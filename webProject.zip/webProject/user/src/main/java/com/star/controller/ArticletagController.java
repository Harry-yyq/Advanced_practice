package com.star.controller;

import com.star.controller.viewobject.ArticletagVO;
import com.star.error.BusinessException;
import com.star.error.EmBusinessError;
import com.star.response.CommonReturnType;
import com.star.service.ArticletagService;
import com.star.service.model.ArticletagModel;
import com.star.write.Writelog;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

@Controller("articletag")
@RequestMapping("/articletag")
@CrossOrigin(allowCredentials = "true", allowedHeaders = "*")
public class ArticletagController extends BaseController {
    @Autowired
    private ArticletagService articletagService;

    @RequestMapping(value = "/create", method = {RequestMethod.POST}, consumes = {CONTENT_TYPE_FORMED})
    @ResponseBody
    public CommonReturnType createArticleTag(@RequestParam(name="articleId") Integer articleId,
                                          @RequestParam(name="articleTitle") String articleTitle,
                                          @RequestParam(name="articleContent") String articleContent,
                                          @RequestParam(name="articleDate") String articleDate,
                                             @RequestParam(name="tagId") Integer tagId,
                                             @RequestParam(name="tagName") String tagName,
                                          @RequestParam(name="userId") Integer userId) throws BusinessException {
        ArticletagModel articletagModel = new ArticletagModel();
        articletagModel.setArticleId(articleId);
        articletagModel.setArticleTitle(articleTitle);
        articletagModel.setArticleContent(articleContent);
        articletagModel.setArticleDate(articleDate);
        articletagModel.setTagId(tagId);
        articletagModel.setTagName(tagName);
        articletagModel.setUserId(userId);

        articletagModel = articletagService.createArticletag(articletagModel);

        ArticletagVO articletagVO = convertFromModel(articletagModel);
        Writelog writelog = new Writelog();
        writelog.saveAsFileWriter("create the articletag");
        return CommonReturnType.create(articletagVO);
    }

    @RequestMapping(value = "/delete", method = {RequestMethod.POST})
    @ResponseBody
    public String deleteArticleTag(@RequestParam(name="articleId",required = false) Integer articleId,
                                @RequestParam(name="tagId",required = false) Integer tagId){
        articletagService.deleteArticletagByTwo(articleId,tagId);
        Writelog writelog = new Writelog();
        writelog.saveAsFileWriter("delete the articletag");
        System.out.println("delete controller");
        return "success";
    }

    @RequestMapping("/get")
    @ResponseBody
    public CommonReturnType getArticleTag(@RequestParam(name="articletagId") Integer articletagId) throws BusinessException{
        ArticletagModel articletagModel = articletagService.getArticletagById(articletagId);
        if(articletagModel == null){
            throw new BusinessException(EmBusinessError.ARTICLETAG_NOT_EXIST);
        }
        ArticletagVO articletagVO = convertFromModel(articletagModel);
        Writelog writelog = new Writelog();
        writelog.saveAsFileWriter("get the articletag");
        return CommonReturnType.create(articletagVO);
    }

    @RequestMapping(value = "/listbyarticle", method = {RequestMethod.GET})
    @ResponseBody
    public CommonReturnType listTagByArticle(@RequestParam(name="articleId") Integer articleId){
        List<ArticletagModel> tagByArticleModelList = articletagService.listTagByArticle(articleId);

        List<ArticletagVO> tagByArticleVOList = tagByArticleModelList.stream().map(tagByArticleModel -> {
            ArticletagVO tagByArticleVO = convertFromModel(tagByArticleModel);
            return tagByArticleVO;
        }).collect(Collectors.toList());
        Writelog writelog = new Writelog();
        writelog.saveAsFileWriter("list the articletag by article");
        return CommonReturnType.create(tagByArticleVOList);
    }

    @RequestMapping(value = "/listbytag", method = {RequestMethod.GET})
    @ResponseBody
    public CommonReturnType listArticleByTag(@RequestParam(name="tagId") Integer tagId){
        List<ArticletagModel> articleByTagModelList = articletagService.listArticleByTag(tagId);

        List<ArticletagVO> articleByTagVOList = articleByTagModelList.stream().map(articleByTagModel -> {
            ArticletagVO articleByTagVO = convertFromModel(articleByTagModel);
            return articleByTagVO;
        }).collect(Collectors.toList());
        Writelog writelog = new Writelog();
        writelog.saveAsFileWriter("list the articletag by tag");
        return CommonReturnType.create(articleByTagVOList);
    }

    private ArticletagVO convertFromModel(ArticletagModel articletagModel){
        if(articletagModel == null){
            return null;
        }

        ArticletagVO articletagVO = new ArticletagVO();
        BeanUtils.copyProperties(articletagModel, articletagVO);

        return articletagVO;
    }
}
