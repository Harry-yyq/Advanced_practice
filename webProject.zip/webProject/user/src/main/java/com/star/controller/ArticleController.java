package com.star.controller;

import com.star.controller.viewobject.ArticleVO;
import com.star.error.BusinessException;
import com.star.error.EmBusinessError;
import com.star.response.CommonReturnType;
import com.star.service.ArticleService;
import com.star.service.ArticletagService;
import com.star.service.model.ArticleModel;
import com.star.write.Writelog;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

@Controller("article")
@RequestMapping("/article")
@CrossOrigin(allowCredentials = "true", allowedHeaders = "*")
public class ArticleController extends BaseController {
    @Autowired
    private ArticleService articleService;

    @Autowired
    private ArticletagService articletagService;

    @RequestMapping(value = "/create", method = {RequestMethod.POST}, consumes = {CONTENT_TYPE_FORMED})
    @ResponseBody
    public CommonReturnType createArticle(@RequestParam(name="articleTitle",required = false) String articleTitle,
                                          @RequestParam(name="articleContent",required = false) String articleContent,
                                          @RequestParam(name="articleDate",required = false) String articleDate,
                                          @RequestParam(name="userId",required = false) Integer userId) throws BusinessException {
        ArticleModel articleModel = new ArticleModel();
        articleModel.setArticleTitle(articleTitle);
        articleModel.setArticleContent(articleContent);
        articleModel.setArticleDate(articleDate);
        articleModel.setUserId(userId);

        articleModel = articleService.createArticle(articleModel);

        ArticleVO articleVO = convertFromModel(articleModel);
        Writelog writelog = new Writelog();
        writelog.saveAsFileWriter("create the article");
        return CommonReturnType.create(articleVO);
    }

    @RequestMapping(value = "/delete", method = {RequestMethod.POST})
    @ResponseBody
    public String deleteArticle(@RequestParam(name="articleId") Integer articleId){
        articletagService.deleteArticletagByArticle(articleId);
        articleService.deleteArticle(articleId);
        Writelog writelog = new Writelog();
        writelog.saveAsFileWriter("delete the article");
        System.out.println("delete controller");
        return "success";
    }

    @RequestMapping("/get")
    @ResponseBody
    public CommonReturnType getArticle(@RequestParam(name="articleId") Integer articleId) throws BusinessException{
        ArticleModel articleModel = articleService.getArticleById(articleId);
        if(articleModel == null){
            throw new BusinessException(EmBusinessError.ARTICLE_NOT_EXIST);
        }
        ArticleVO articleVO = convertFromModel(articleModel);
        Writelog writelog = new Writelog();
        writelog.saveAsFileWriter("get the article");
        return CommonReturnType.create(articleVO);
    }

    @RequestMapping(value = "/list", method = {RequestMethod.GET})
    @ResponseBody
    public CommonReturnType listArticle(){
        List<ArticleModel> articleModelList = articleService.listArticle();

        List<ArticleVO> articleVOList = articleModelList.stream().map(articleModel -> {
            ArticleVO articleVO = convertFromModel(articleModel);
            return articleVO;
        }).collect(Collectors.toList());
        Writelog writelog = new Writelog();
        writelog.saveAsFileWriter("list the article");
        return CommonReturnType.create(articleVOList);
    }

    @RequestMapping(value = "/listbyuser", method = {RequestMethod.GET})
    @ResponseBody
    public CommonReturnType listArticleByUser(@RequestParam(name="userId") Integer userId){
        List<ArticleModel> articleByUserModelList = articleService.listArticleByUser(userId);

        List<ArticleVO> articleByUserVOList = articleByUserModelList.stream().map(articleByUserModel -> {
            ArticleVO articleByUserVO = convertFromModel(articleByUserModel);
            return articleByUserVO;
        }).collect(Collectors.toList());
        Writelog writelog = new Writelog();
        writelog.saveAsFileWriter("list the article by user");
        return CommonReturnType.create(articleByUserVOList);
    }

    private ArticleVO convertFromModel(ArticleModel articleModel){
        if(articleModel == null){
            return null;
        }

        ArticleVO articleVO = new ArticleVO();
        BeanUtils.copyProperties(articleModel, articleVO);

        return articleVO;
    }
}
