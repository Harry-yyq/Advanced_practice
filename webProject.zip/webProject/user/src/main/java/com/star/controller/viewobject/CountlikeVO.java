package com.star.controller.viewobject;

public class CountlikeVO {
    private Integer countlike;

    public Integer getCountlike() {
        return countlike;
    }

    public void setCountlike(Integer countlike) {
        this.countlike = countlike;
    }
}
