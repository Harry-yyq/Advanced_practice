package com.star.service;

import com.star.error.BusinessException;
import com.star.service.model.LeaderModel;

import java.util.List;

public interface LeaderService {
    LeaderModel getLeaderById(Integer id);
    LeaderModel createLeader(LeaderModel leaderModel) throws BusinessException;
    List<LeaderModel> listLeader();
    void updateLeader(String leaderName,String leaderIntro,String leaderPost);
    void deleteLeader(Integer id);
}
