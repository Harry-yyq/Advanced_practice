package com.star.controller.viewobject;

public class CountcommentVO {
    private Integer countcomment;

    public Integer getCountcomment() {
        return countcomment;
    }

    public void setCountcomment(Integer countcomment) {
        this.countcomment = countcomment;
    }
}
