package com.star.controller;

import com.star.controller.viewobject.ArticlelikeVO;
import com.star.controller.viewobject.CountlikeVO;
import com.star.error.BusinessException;
import com.star.error.EmBusinessError;
import com.star.response.CommonReturnType;
import com.star.service.ArticlelikeService;
import com.star.service.model.ArticlelikeModel;
import com.star.write.Writelog;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

@Controller("articlelike")
@RequestMapping("/articlelike")
@CrossOrigin(allowCredentials = "true", allowedHeaders = "*")
public class ArticlelikeController extends BaseController{
    @Autowired
    private ArticlelikeService articlelikeService;

    @RequestMapping(value = "/create", method = {RequestMethod.POST}, consumes = {CONTENT_TYPE_FORMED})
    @ResponseBody
    public CommonReturnType createArticlelike(@RequestParam(name="articleId") Integer articleId,
                                             @RequestParam(name="userId") Integer userId) throws BusinessException {
        ArticlelikeModel articlelikeModel = new ArticlelikeModel();
        articlelikeModel.setArticleId(articleId);
        articlelikeModel.setUserId(userId);

        articlelikeModel = articlelikeService.createArticlelike(articlelikeModel);

        ArticlelikeVO articlelikeVO = convertFromModel(articlelikeModel);
        Writelog writelog = new Writelog();
        writelog.saveAsFileWriter("create the like");
        return CommonReturnType.create(articlelikeVO);
    }

    @RequestMapping(value = "/delete", method = {RequestMethod.POST})
    @ResponseBody
    public String deleteArticlelike(@RequestParam(name="articleId") Integer articleId,
                                   @RequestParam(name="userId") Integer userId){
        articlelikeService.deleteArticlelike(articleId,userId);
        Writelog writelog = new Writelog();
        writelog.saveAsFileWriter("delete the like");
        System.out.println("delete controller");
        return "success";
    }

    @RequestMapping("/get")
    @ResponseBody
    public CommonReturnType getArticlelike(@RequestParam(name="articlelikeId") Integer articlelikeId) throws BusinessException{
        ArticlelikeModel articlelikeModel = articlelikeService.getArticlelikeById(articlelikeId);
        if(articlelikeModel == null){
            throw new BusinessException(EmBusinessError.ARTICLELIKE_NOT_EXIST);
        }
        ArticlelikeVO articlelikeVO = convertFromModel(articlelikeModel);
        Writelog writelog = new Writelog();
        writelog.saveAsFileWriter("get the like");
        return CommonReturnType.create(articlelikeVO);
    }

    @RequestMapping(value = "/count", method = {RequestMethod.GET})
    @ResponseBody
    public CountlikeVO countArticlelike(@RequestParam(name="articleId") Integer articleId){
        Writelog writelog = new Writelog();
        writelog.saveAsFileWriter("count the like");
        CountlikeVO countlikeVO = new CountlikeVO();
        countlikeVO.setCountlike(articlelikeService.countArticlelike(articleId));
        return countlikeVO;
    }

    private ArticlelikeVO convertFromModel(ArticlelikeModel articlelikeModel){
        if(articlelikeModel == null){
            return null;
        }

        ArticlelikeVO articlelikeVO = new ArticlelikeVO();
        BeanUtils.copyProperties(articlelikeModel, articlelikeVO);

        return articlelikeVO;
    }
}
