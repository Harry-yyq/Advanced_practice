package com.star.write;

import java.io.*;
import java.util.ArrayList;

public class Writelog {
    private String filePath = "src/main/java/com/star/write/log.txt";

    public void saveAsFileWriter(String content) {
        FileWriter fwriter = null;
        System.out.println(content);
        try {
            fwriter = new FileWriter(filePath, true);
            fwriter.write(content);
        } catch (IOException ex) {
            ex.printStackTrace();
        } finally {
            try {
                fwriter.flush();
                fwriter.close();
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }
    }
}
