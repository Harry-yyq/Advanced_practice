package com.star.error;

public enum EmBusinessError implements CommonError {
    // 通用错误类型 10001
    PARAMETER_VALIDATION_ERROR(10001, "参数不合法"),
    UNKNOWN_ERROR(10002, "未知错误"),

    // 20000 开头为用户信息相关错误定义
    USER_NOT_EXIST(20001, "用户不存在"),
    USER_LOGIN_FAIL(20002,"登录失败"),
    ARTICLE_NOT_EXIST(20003,"帖子不存在"),
    TAG_NOT_EXIST(20004,"标签不存在"),
    ARTICLETAG_NOT_EXIST(20005,"关系不存在"),
    COMMENT_NOT_EXIST(20006,"评论不存在"),
    ARTICLELIKE_NOT_EXIST(20007,"点赞不存在"),
    COMPANY_NOT_EXIST(20008,"公司简介不存在"),
    LEADER_NOT_EXIST(20009,"领导不存在"),
    REPORT_NOT_EXIST(20010,"报告不存在"),
    ;

    private int errCode;
    private String errMsg;

    private EmBusinessError(int errCode, String errMsg){
        this.errCode = errCode;
        this.errMsg = errMsg;
    }

    @Override
    public int getErrCode() {
        return this.errCode;
    }

    @Override
    public String getErrMsg() {
        return this.errMsg;
    }

    @Override
    public CommonError setErrMsg(String errMsg) {
        this.errMsg = errMsg;
        return this;
    }
}