package com.star.service;

import com.star.dao.UserDOMapper;
import com.star.error.BusinessException;
import com.star.service.model.UserModel;

import java.util.List;

public interface UserService{
    UserModel getUserById(Integer id);
    UserModel getUserByPhone(String userPhone);
    List<UserModel> listUser();
    void register(UserModel userModel) throws BusinessException;
    UserModel login(String userPhone, String userPassword) throws BusinessException;
    void updateWorker(Integer userWorker, Integer id);
    void updateLogin(Integer userLogin, String userPhone);
    void updatePassword(String userPssword, Integer id);
}
